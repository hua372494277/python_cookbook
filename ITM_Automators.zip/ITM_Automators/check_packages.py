#!/usr/bin/env python
# @Filename: check_packages.py
# @Author: huayp
# @Date: 2018-02-09 14:56
# -*- coding: utf-8 -*-

import os
import sys
import string
import psutil
import re

# def get_pid(name):
name = 'QQ'
process_list = psutil.pids()

for pid in process_list:
    pidDictionary = psutil.Process(pid).as_dict(attrs=['pid', 'name', 'username', 'exe', 'create_time']);
    for keys in pidDictionary.keys():
        tempText = keys + ':' + str(pidDictionary[keys]) + '\n'

