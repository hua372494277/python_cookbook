#!/usr/bin/env python
# @Filename: github_trigger_itm.py
# @Author: huayp
# @Date: 2017-11-21 11:35
# -*- coding: utf-8 -*-

from lib.github.github_operate import GitHubOperate
import time
import logging

class GitHubTriggerITM(object):
    def __init__(self):
        self.github_operator = GitHubOperate()

    def send_to_github(self, times):
        logging.info("Hit %s to github" % times)
        if times < 1:
            return

        self.github_operator.create_branch()
        for i in range(0, times):
            self.github_operator.write_one_random_file()
            self.github_operator.add()
            self.github_operator.commit()
            self.github_operator.push()
            self.github_operator.delete_random_file()
            self.github_operator.commit()
            self.github_operator.push()
            time.sleep(10)

        self.github_operator.delete_branch()

if __name__ == '__main__':
    github_trigger = GitHubTriggerITM()
    github_trigger.send_to_github(5)