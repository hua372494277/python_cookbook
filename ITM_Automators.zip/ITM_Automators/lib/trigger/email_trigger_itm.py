#!/usr/bin/env python
# @Filename: email_trigger_itm.py
# @Author: huayp
# @Date: 2017-10-23 14:18
# -*- coding: utf-8 -*-


from lib.emails.smtp_email import SMTPEmail
from lib.emails.normal_email import NormalEmail
from lib.emails.forward_email import ForwardEmail
from lib.emails.bcc_email import BCCEmail
import datetime
import os.path
import copy
import inspect

'''
This class could trigger all ITM Strategies by sending the emails,
and also check if it is captured and logged in ES.

The following parameters are required for sending emails:
    from_email 
    passwd_email
    smtp_name
    to_emails=[]
    bcc_emails=[]
    
attachment_paths is optional. When it is not provided,
but trigger_itms is provided by calling trigger_itms().
The attachment will be generated from lib/emails/attachments.

This script support to be execute from command line.
But the required parameters need to be provide. 
'''

class EmailTriggerITM(object):
    def __init__(self, from_email,
                       passwd_email,
                       smtp_name,
                       subject="这是一封测试ITM专家系统的邮件",
                       to_emails=[],
                       bcc_emails=[],
                       content="This email is to test ITM System",
                       attachment_paths=[]
                       ):
        if from_email == "":
            raise AssertionError("Error: from_email should not be empty.")

        self.smtp_email = SMTPEmail(from_email= from_email,
                               passwd_email = passwd_email,
                               smtp_name = smtp_name)

        self.subject = subject
        self.to_emails = to_emails
        self.bcc_emails = bcc_emails
        self.content = content
        self.attachment_paths = copy.copy(attachment_paths)

        this_file_abspath = inspect.getfile(inspect.currentframe())
        current_dir = os.path.dirname(this_file_abspath)
        # current_dir is "...lib\trigger\email_trigger_itm.py
        # attachment file path is "....lib\emails\attechments\..."
        # So make up the attachment path when only specify the ITM strategies expected to trigger
        # but do not provide the attachments.
        # Then
        self.attachment_dir = os.path.join(current_dir, '..', 'emails', 'attachments')

    # '''
    # Get the docs' paths to trigger multi-ITM strategies
    # '''
    # def get_docs_trigger_itms(self, trigger_itms = []):
    #     docs_trig_itms = {
    #         "itm-01" : "ITM-01-encrypted_file.docx",
    #         "itm-02" : "ITM-02-unknown_type.data",
    #         "itm-03" : "ITM-03-SAM_Passwd",
    #         "itm-04" : "ITM-04-id_rsa",
    #         "itm-05" : "ITM-05-resume.pdf",
    #         "itm-06" : "ITM-06-employee.xlsx",
    #         "itm-07" : "ITM-07-cust_info.xlsx",
    #         "itm-08" : "ITM-08.c",
    #         "itm-09" : "ITM-09-bad_info.txt"
    #     }
    #
    #     doc_paths = []
    #     for trigger_itm in trigger_itms:
    #         if trigger_itm in docs_trig_itms:
    #             abs_path = os.path.join(self.attachment_dir, docs_trig_itms[trigger_itm])
    #             doc_paths.append(abs_path)
    #         elif trigger_itm == "itm-10" or trigger_itm == "itm-11":
    #             continue
    #         else:
    #             raise AssertionError("Error: '%s' is not in default ITM Strategies." % trigger_itm)
    #
    #     return doc_paths

    def add_attachment(self, paths):
        for path in paths:
            self.attachment_paths.append(path)

    '''
    Usage: if want to trigger itm-01 and itm-10
    Then, instance.trigger_itms(trigger_itms = ["itm-01", "itm-10"])
    Return:
        The time when itm strategies are triggered.
    '''
    def trigger(self, bcc = False, fw = False):
        one_eml = NormalEmail(subject=self.subject,
                              to_emails=self.to_emails,
                              bcc_emails=[],
                              content=self.content,
                              attachment_paths=self.attachment_paths)

        if bcc:
            one_eml = BCCEmail(one_eml, bcc_emails=self.bcc_emails)

        if fw:
            one_eml = ForwardEmail(one_eml)

        self.smtp_email.send(one_eml)
        return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def help():
    print('Usage: %s \n' % os.path.basename(sys.argv[0]) +
          'python -m lib.email_trigger_itm ......\n' +
          '\tfrom_email=aaabbb@ccc.com\n' +
          '\tpasswd_email=aaabbb\n' +
          '\tsmtp_name=ccc\n' +
          '\tsubject=\"ITM System Test Email\"\n' +
          '\tto_emails=[dddfff@eee.com,...]\n' +
          '\tbcc_emails=[]\n' +
          '\tcontent=\"This email is to test ITM System\"\n' +
          '\tattachment_paths=[]\n' +
          '\tbcc=false\n' +
          '\tfw=false\n' +
          '\tNo blanks in value\n')

def convert_to_list(arg_str):
    arg_list = arg_str[1:-1].split(',')
    return arg_list


if __name__ == "__main__":
    import sys
    paras ={'from_email': "",
            'passwd_email': "",
            'smtp_name': "",
            'subject': "ITM System Test Email",
            'to_emails': [],
            'bcc_emails': [],
            'content': "This email is to test ITM System",
            'attachment_paths': [],
            'bcc': "",
            'fw': ""}

    args = sys.argv[1:]
    for arg in args:
        try:
            (key, value) = arg.split('=')
        except ValueError:
            print("No blanks in value")
            print()
            exit(0)

        if key in paras:
            if key in ['to_emails', 'bcc_emails', 'attachment_paths']:
                paras[key] = convert_to_list(value)
            elif key in ['bcc', 'fw']:
                if value.lower() == 'true':
                    paras[key] = True
                else:
                    paras[key] = False
            else:
                paras[key] = value
        else:
            help()
            exit(0)


    eml_trigger_itm = EmailTriggerITM(from_email=paras['from_email'],
                                      passwd_email=paras['passwd_email'],
                                      smtp_name=paras['smtp_name'],
                                      subject=paras['subject'],
                                      to_emails=paras['to_emails'],
                                      bcc_emails=paras['bcc_emails'],
                                      content=paras['content'],
                                      attachment_paths=paras['attachment_paths'],
                                      )
    # print(eml_trigger_itm.get_docs_trigger_itms(trigger_itms=paras['trigger_itms']))

    eml_trigger_itm.trigger(bcc=paras['bcc'], fw=paras['fw'])