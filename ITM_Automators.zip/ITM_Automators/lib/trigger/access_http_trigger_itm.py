#!/usr/bin/env python
# @Filename: access_http_trigger_itm
# @Author: huayp
# @Date: 2017-11-16 19:15
# -*- coding: utf-8 -*-

import urllib.request
import logging
import random
import time
import subprocess
import os
import ssl
import socket

class AccessHTTPTriggerITM(object):
    def __init__(self):
        self.website = {
                            'bbs': ['http://bbs.tianya.cn/', 'http://weibo.com', 'http://www.globeofblogs.com',
                                    'http://mathewanderson.blogspot.com',
                                    'http://www.blogsrater.com', 'http://ldsjournal.com', 'http://michellemalkin.com',
                                    'http://patrilablogger.blogspot.com', 'http://ushighway83.blogspot.com',
                                    'http://sisterhannahgalli.blogspot.com', 'http://reyney.blogspot.com',
                                    'http://stanblogging.tumblr.com', 'http://sojournerinlabrador.blogspot.com',
                                    'https://laughingsquid.com', 'http://blogsome.com', 'http://blog.lproof.org',
                                    'http://www.way2blogging.org', 'https://blogville.us', 'https://www.blogcatalog.com',
                                    'http://topblogging.com', 'http://wordpressblogdirectory.com','https://forum.cmsmadesimple.org',
                                    'http://www.graphicdesignforums.co.uk', 'https://www.inforum.in',
                                    'https://forum.videohelp.com', 'https://www.sinodefenceforum.com',
                                    'https://abdlstoryforum.info', 'http://forum.osxlatitude.com', 'https://forums.neons.org',
                                    'http://forum.aerosoft.com', 'http://www.americasdebate.com', 'https://forum.postcrossing.com',
                                    'http://www.yuku.com', 'http://www.roundcubeforum.net', 'http://forums.thedarkmod.com',
                                    'http://www.india-forums.com', 'http://www.nybass.com', 'https://longhaircareforum.com',
                                    'http://businessopportunityforum.com', 'https://forum.cgpersia.com',
                                    'http://forums.nexopia.com', 'http://www.talkonaut.com', 'http://www.answers.com',
                                    'http://www.vteen.com', 'http://www.chatzy.com', 'http://www.chatterous.com',
                                    'http://kupika.com', 'http://www.teenhive.com', 'http://www.faceparty.com',
                                    'http://www.bharatstudent.com', 'https://tinychat.com', 'https://www.chat.com',
                                    'http://www.penpalsonline.com', 'http://www.chathour.com', 'http://rentafriend.com',
                                    'https://icq.com/windows/en', 'https://secure.tagged.com/?loc=en_US',
                                    'http://www.friendship.com.au', 'http://mypage5.com'],
                            'adult': ['http://mmkao.net/', 'http://kk747.com/',
                                      'http://www.eqaicc.com.cn/'],
                            'recruit': ['http://www.zhaopin.com',
                                        'http://www.dasanya.com',
                                        'http://www.neitui.me','https://www.recruiter.com', 'http://www.nationjob.com',
                                        'https://jobcenterofwisconsin.com', 'http://www.bluefin-recruitment.com',
                                        'http://workinstartups.com', 'http://the-job-network.com',
                                        'https://www.newhavencountyjobs.com', 'https://www.freelancers.net',
                                        'https://jobs.livecareer.com', 'https://jobs.lifetimefitness.com',
                                        'https://www.sologig.com', 'https://www.aerotek.com', 'http://www.bestjobsnetwork.com',
                                        'http://www.chicagojobs.com', 'https://www.governmentjobs.com', 'http://www.juju.com',
                                        'https://www.workabroad.ph', 'https://merojob.com', 'http://gtsrecruitment.com'
                                        ],
                            'unsafe':['http://mantoub.com/favicon.ico'],
                            'virus': ['http://i.kpzip.com/n/tui/poploader/v1.0.0.2/poploader-8.exe'],
                            'search': ['http://www.baidu.com', 'http://www.bing.com'],
                            'news': ['http://news.sina.com.cn', 'http://v.ifeng.com/mil/', 'http://www.eastmoney.com/?ocid=MSNCNLG7-1',
                                     'http://news.qq.com/?ocid=MSNCNLG2-3', 'http://blog.fantasy.co', 'https://www.chrobinson.com/en-US',
                                     'http://tateswood.com', 'http://www.agmfg.net', 'http://www.topshelflogistics.com',
                                     'http://www.logisticstaiwan.com', 'https://www.its4logistics.com', 'http://www.r-z-logistics.com',
                                     'http://www.meyer-logistics.com', 'http://www.nlenergyco.com', 'http://www.newmont.com',
                                     'http://www.echo.com', 'https://www.gulfportenergy.com', 'http://www.schaferlogistics.com',
                                     'https://goshippo.com', 'http://www.brandconn.com', 'http://pharmalogisticspartner.com',
                                     'http://tadmurlogistics.com', 'http://www.goodstransportation.com',
                                     'http://www.jacksoncounty.in.gov', 'https://www.azleg.gov', 'http://nj.gov',
                                     'http://www.dttas.ie', 'https://www.iowa.gov', 'http://www.cbec.gov.in',
                                     'http://www.cityofkeywest-fl.gov', 'http://www.dirco.gov.za',
                                     'https://gibraltar.gov.gi', 'https://www.commerce.gov',
                                     'http://web.culpepercounty.gov', 'http://www1.nyc.gov', 'https://va.gov',
                                     'https://www.gov.uk/government/organisations/foreign-commonwealth-office',
                                     'http://www.taiwan.gov.tw', 'https://www.canada.ca/en/revenue-agency.html',
                                     'https://www.gov.jm', 'http://www.surrycountyva.gov', 'http://ncm.nic.in',
                                     'https://www.allsides.com', 'https://www.texastribune.org',
                                     'https://tytnetwork.com', 'https://www.themarshallproject.org',
                                     'http://www.mysanantonio.com', 'https://www.chinadaily.com.cn',
                                     'https://www.voanews.com', 'http://www.ocala.com', 'http://www.newsherald.com',
                                     'http://www.timesnewspapers.com', 'https://www.good.is',
                                     'http://www.shreveporttimes.com'],
                            'Tech': ['http://skype.gmw.cn/?ocid=MSNCNLG11-1', 'https://www.macrumors.com', 'http://gadgets.ndtv.com',
                                     'http://www.networkcomputing.com', 'https://www.imore.com', 'http://www.anddev.org',
                                     'http://www.techshortly.com', 'http://www.apcmag.com', 'https://www.sonymobile.com',
                                     'https://www.online-tech-tips.com', 'http://www.macnn.com', 'https://davidwalsh.name',
                                     'https://www.lifewire.com', 'http://www.geniouspc.com', 'https://techivian.com',
                                     'https://www.technipages.com', 'https://www.scienceworld.ca', 'https://www.itworld.com',
                                     'http://www.tmonews.com', 'https://www.techntrack.org', 'http://www.techcrates.com'],
                            'Education': ['http://www.jd100.com/', 'http://samnoblemuseum.ou.edu', 'https://www.nae.edu',
                                          'http://www.warmuseum.ca', 'https://www2.acadiau.ca', 'http://www.ntu.edu.sg',
                                          'https://www.northampton.ac.uk', 'https://www.abdn.ac.uk', 'https://www.qmu.ac.uk',
                                          'http://indianmuseumkolkata.org', 'https://www.khanacademy.org',
                                          'https://www.ucl.ac.uk', 'http://www.exeter.ac.uk', 'https://www.saylor.org',
                                          'http://www.birmingham.ac.uk', 'https://www.southampton.ac.uk',
                                          'http://www.deakin.edu.au', 'http://www.learningace.com',
                                          'http://crandalllibrary.org', 'http://www.du.ac.in',
                                          'http://www.essentialkids.com.au', 'http://www.mom365.com',
                                          'http://www.pregnancy-weekbyweek.com', 'http://www.actionforhealthykids.org',
                                          'http://www.savvysassymoms.com/blog/category/kids-section',
                                          'http://www.babyuniversity.com', 'https://www.pregnancycorner.com',
                                          'http://www.parentscanada.com', 'http://www.baby2see.com',
                                          'https://www.babycentre.co.uk', 'http://livebabycare.com',
                                          'https://community.pregnancy.org', 'https://www.tommys.org',
                                          'https://www.positiveparentingsolutions.com', 'http://www.instinctiveparenting.com',
                                          'http://www.pregnancyetc.com', 'http://www.pregnancyhut.com', 'http://mylovingcare.com'],
                            'mail': ['http://mail.126.com', 'http://mail.qq.com', 'http://outlook.live.com'],
                            'hobbies': ['http://canadiancoin.com', 'https://ifishillinois.org', 'https://www.wine.com',
                                        'https://www.stampcenter.com', 'https://www.theflyfishers.com', 'http://www.catster.com',
                                        'http://en.origami-club.com', 'https://shop.lego.com/en-US', 'http://customrubiks.com',
                                        'http://www.bigfishtackle.com', 'https://www.greatbritainstamps.net',
                                        'http://www.elkhunting.com', 'http://www.howtodotricks.com', 'http://conphilinc.com',
                                        'https://www.decanterchina.com/en', 'https://www.sandafayre.com', 'https://www.colonialacres.com',
                                        'http://www.doityourself.com', 'https://www.huntingnet.com'],
                            'traffic': ['https://erail.in', 'http://www.buseireann.ie', 'http://valleyride.org',
                                        'http://www.pandorabus.com', 'https://m.redbus.in',
                                        'http://www.busonlineticket.com', 'https://lufthansa-cargo.com',
                                        'https://www.theoriginaltour.com', 'https://www.dashbus.com', 'http://www.boeing.com',
                                        'https://www.aucklandairport.co.nz', 'http://www.number1bus.com', 'https://www.coachcanada.com',
                                        'http://www.amtrakcalifornia.com', 'http://www.indianrail.gov.in', 'http://www.acerentacar.com',
                                        'https://www.e-zrentacar.com', 'http://www.airasiax.com', 'https://www.kayak.co.uk'],
                            'sports': ['http://www.internationalbadminton.org', 'http://www.wimbledon.com', 'https://www.usab.com',
                                       'https://www.sailing.ie', 'https://southamptonfc.com', 'http://www.afl.com.au',
                                       'http://www.canadasoccer.com', 'http://www.livescore.com',
                                       'http://www.issf-sports.org', 'https://www.mykhel.com'],
                            'music': ['http://musicbeats.net', 'http://zenmix.io', 'http://www.rapbasement.com',
                                      'http://www.musicconnection.com', 'https://hiphopisdream.win',
                                      'http://en.musicplayon.com', 'http://zh.musicplayon.com',
                                      'http://habumusic.com', 'http://stereokiller.com', 'https://my-free-mp3.net',
                                      'http://www.lyricsfreak.com', 'https://songs.pk', 'https://www.solopianoradio.com',
                                      'http://monsterguitars.com', 'http://www.classical-music.com', 'https://musicmoz.org',
                                      'https://prettymuchamazing.com', 'https://www.lyrics.com'],
                            'travel': ['http://travour.com', 'http://vietnamtravelinformation.net', 'http://www.vacationstogo.com',
                                       'https://www.infohub.com', 'https://www.stb.gov.sg', 'http://www.travelpage.com',
                                       'http://www.savannah.com', 'https://www.tripoto.com', 'http://www.vanaqua.org',
                                       'http://www.visitguatemala.com', 'http://www.visitessex.com', 'http://www.justspain.org',
                                       'http://www.londontown.com', 'http://www.californiatravelcenter.com',
                                       'https://www.cedarpoint.com', 'http://magnificenttravel.com', 'http://tourmycountry.com',
                                       'http://www.chinaholidays.com', 'https://digjapan.travel/en/'],
                            'literature': ['https://www.thebookseller.com', 'https://openliterature.net',
                                           'http://www.gutenberg.org', 'https://heydaybooks.com/book_category/newreleases',
                                           'http://www.nybooks.com', 'http://www.ebooklobby.com', 'https://www.pw.org',
                                           'http://kitaabghar.com', 'https://readersfavorite.com', 'http://booksforears.com',
                                           'http://www.poemsonly.com', 'http://www.planetebook.com', 'http://www.sfwa.org',
                                           'http://literature-study-online.com', 'http://www.penguin.com',
                                           'https://www.goodreads.com', 'http://www.bookreporter.com', 'https://www.thriftbooks.com',
                                           'http://artunframed.com', 'https://www.americanartcollector.com',
                                           'http://www.artinstructionblog.com', 'http://www.pghopera.org',
                                           'http://parisoperafilm.com', 'https://www.artslant.com', 'http://www.artnews.com',
                                           'http://www.artprints.com', 'https://www.saatchiart.com', 'http://www.theartgallery.com.au',
                                           'http://www.fgo.org', 'http://olddesignshop.com', 'http://www.artistdaily.com',
                                           'http://www.oil-painting-reproduction.com', 'http://www.theintersection.org',
                                           'https://www.artincanada.com', 'http://www.nmartists.com', 'http://www.bronxriverart.org',
                                           'http://ego-alterego.com', 'http://www.silentfilm.org'
                                           ],
                            'Games': ['http://www.twizl.com', 'http://www.onemorelevel.com', 'http://playkix.com',
                                      'http://www.gamewinners.com', 'https://www.polygon.com', 'https://www.gameplanet.com.au',
                                      'http://www.bigmoneyarcade.com', 'http://www.worldoflogs.com', 'http://www.freegamesjungle.com',
                                      'http://www.gamefront.com', 'https://www.activisionblizzard.com', 'http://www.topofgames.com',
                                      'http://www.flashgames247.com', 'http://addictinggames247.com', 'http://www.1up.com',
                                      'http://www.onrpg.com', 'https://www.dcuniverseonline.com', 'http://www.gamefools.com',
                                      'https://www.ubisoft.com'],
                            'unclassified':['http://f11.baidu.com/it/u=1041981208,1162127471&fm=76',
                                            'http://f10.baidu.com/it/u=3960342135,982458232&fm=76',
                                            'https://csdnimg.cn/release/phoenix/production/main-aa20801f57.css',
                                            'https://shared.ydstatic.com/js/yatdk/3.0.0/stream.js',
                                            'https://ss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=1242571638,3938332845&fm=58',
                                            'https://adservice.google.com/adsid/integrator.js?domain=fragment.firefoxchina.cn',
                                            ],
                        }


    def access(self, type):
        random_index = random.randint(0, len(self.website[type]) -1 )
        website = self.website[type][random_index]

        if type in ['virus']:
            process = subprocess.Popen(['curl', '-o', 'C:\\Users\\admin\\Downloads\\hello.exe', website], universal_newlines=True, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT)
            print(process.communicate()[0].strip())
            if os.path.exists('C:\\Users\\admin\\Downloads\\hello.exe'):
                print("Download success")
                os.remove('C:\\Users\\admin\\Downloads\\hello.exe')
            else:
                print("Fail Download Trojan file")
        else:
            logging.info("Access website: " + website)
            try:
                context = ssl._create_unverified_context()
                html = urllib.request.urlopen(website, context=context).read()
            except:
                logging.info("It hits DLP strategies.")
                pass

    def multi_access_with_delay(self, times, type, delay):
        for i in range(0, times):
            socket.setdefaulttimeout(delay)
            self.access(type)
            time.sleep(delay) # extend more delay between accessing websites.


if __name__ == "__main__":
    access_http = AccessHTTPTriggerITM()
    access_http.access("bbs")
    access_http.access("adult")
    access_http.access("virus")