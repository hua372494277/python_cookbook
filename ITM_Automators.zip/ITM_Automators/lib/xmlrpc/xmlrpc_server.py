#!/usr/bin/env python
# @Filename: xmlrpc_server
# @Author: huayp
# @Date: 2017-10-20 09:42
# -*- coding: utf-8 -*-

from xmlrpc.server import SimpleXMLRPCServer
import socket
import subprocess
import os

'''
xmlrpc_server will run on the simulator hosts, which are used to
trigger all kinds of abnormal behavior.
When one command is expected to run on ths host,
client only needs to execute the code like "run_command ....."
The response will be sent back.
'''

class XMLRPCServer(object):
    def __init__(self, service_ip="", service_port=""):
        if service_ip and service_port:
            self.service_ip = service_ip
            self.service_port = int(service_port)
        else:
            hostname =  socket.gethostname()
            self.service_ip = socket.gethostbyname(hostname)
            self.service_port = 8000

        self.xmlrpc_server = SimpleXMLRPCServer((self.service_ip, self.service_port))
        self.xmlrpc_server.register_function(self.run_command, "run_command")
        self.xmlrpc_server.register_function(self.echo, "echo")

    def run_command(self, command):
        print(command)

        process = subprocess.Popen(command, universal_newlines=True, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT)
        return process.communicate()[0].strip()

    def start(self):
        print("Listening on: http://", self.service_ip, ":" ,self.service_port)
        this_file_abspath = os.path.realpath(__file__)
        current_dir = os.path.dirname(this_file_abspath)
        os.chdir(os.path.join("..", ".."))
        print(os.getcwd())
        self.xmlrpc_server.serve_forever()

    def echo(self, words="Hello"):
        return words

if __name__ == "__main__":
    xmlrpc_server = XMLRPCServer()
    # xmlrpc_server = XMLRPCServer(service_ip="localhost", service_port="8000")
    xmlrpc_server.start()
