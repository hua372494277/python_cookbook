#!/usr/bin/env python
# @Filename: xmlrpc_client.py
# @Author: huayp
# @Date: 2017-10-20 15:20
# -*- coding: utf-8 -*-

import xmlrpc.client
import time

'''
This class is used in testing environment.
It will encapsulate the commands, which should be ran on the remote host.
When want to send commands, the steps:
1. init XMLRPCClient  
xmlrpc_client = XMLRPCClient(server_ip="172.22.1.127", server_port=8000)

server_ip is the ip of remote host
server_port is the its port.

2. send the command
For example:
# Get the working directory of running xmlrpc_server on host.
resp = xmlrpc_client.run("python -c \"import os.path; print(os.path.abspath('__file__'))\"")
'''

class XMLRPCClient(object):
    def __init__(self, server_ip="", server_port=""):
        if server_ip and server_port:
            self.xmlrpc_client = xmlrpc.client.ServerProxy("http://" + server_ip + ":" + str(server_port))
        else:
            raise AssertionError("Before starting XML RPC client to communicate with server, "\
                                 +"you have to provide IP and port of server...")

        if self.xmlrpc_client.echo("Hello") == "Hello":
            print("The communication is good")
        else:
            raise AssertionError("XML RPC Server has not been started")

    def run(self, command):
        print(time.strftime('%a, %d %b %Y %H:%M:%S %z') + ":  " + command)
        responses = self.xmlrpc_client.run_command(command)
        return responses


if __name__ == "__main__":
    xmlrpc_client = XMLRPCClient(server_ip="172.22.1.127", server_port=8000)

    # Get the working directory of running xmlrpc_server on host.
    resp = xmlrpc_client.run("python -c \"import os.path; print(os.path.abspath('__file__'))\"")
    print(resp)
    resp = xmlrpc_client.run("cmd /c md hello") # mkdir with name hello
    resp = xmlrpc_client.run("cmd /c rd /q /s hello") #rm -rf


    # transfer files between windows to linux
    # xml_c.run("C:\\ITM_Automators\\pscp.exe -l root -pw Hello123! huab@172.30.5.15:/home/huab/b.txt C:\\ITM_Automators")
    # xmlrpc_client.run("python -m lib.trigger.email_trigger_itm from_email=huayongpan@skyguard.com.cn passwd_email=Tencent123# smtp_name=smtp.skyguard.com.cn subject=noblank to_emails=[yongpanhua@163.com] content=helloworld bcc_emails=[huayp@outlook.com] fw=true ")