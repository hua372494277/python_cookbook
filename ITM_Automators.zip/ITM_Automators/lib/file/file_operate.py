#!/usr/bin/env python
# @Filename: file_operate.py
# @Author: huayp
# @Date: 2017-12-04 16:44
# -*- coding: utf-8 -*-

import tempfile
import string
import random
import os
import uuid

class FileOperator(object):
    def __init__(self):
        self.char_map = string.ascii_letters + string.digits
        self.temp_path = tempfile.gettempdir()

    def generate_one_random_file(self, filename):
        # write char_count characters into README.md
        char_count = random.randint(500, 30000)
        print("File contains %d chars" % char_count)
        with open(os.path.join(self.temp_path, filename), "w") as fw_random_file:
            for i in range(0, char_count):
                fw_random_file.write(self.char_map[random.randint(0, len(self.char_map) - 1)])
                if random.randint(0, 1):
                    fw_random_file.write("\n")

        return os.path.join(self.temp_path, filename)

    def generate_one_random_file_and_name(self):
        filename = str(uuid.uuid1())
        for i in range(0, 10):
            filename = filename + string.ascii_letters[random.randint(0, 51)]

        self.generate_one_random_file(filename)

    def delete_file(self, file_path):
        if os.path.exists(file_path):
            os.remove(file_path)
        else:
            raise AssertionError("%s file is not existing" % file_path)

if __name__ == "__main__":
    file_operator = FileOperator()
    file_operator.temp_path = "D:\\normal"
    for i in range(8):
        file_path=file_operator.generate_one_random_file_and_name()
        # file_operator.delete_file(file_path)
