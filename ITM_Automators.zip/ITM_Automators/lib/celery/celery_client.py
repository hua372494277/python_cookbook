#!/usr/bin/env python
# @Filename: celery_client.py
# @Author: huayp
# @Date: 2017-11-13 18:34
# -*- coding: utf-8 -*-

from celery import Celery
import json

__all__ = ['restart_ers_predict', 'restart_mrs_predict', 'mrs_retrain']

# TODO (huayp) redis the URL should be a parameter, since IP may be different in practice
app = Celery('celery_server', broker='redis://172.30.3.123:6379/0')

@app.task(name='ers_task')
def ers_task(**msg):
    pass

@app.task(name='mrs_task')
def mrs_task(**msg):
    pass

msg_retraining = {"type":2,"deviceID":"12334","taskID":"999999999"}  #training
msg_repredict = {"type":1,"deviceID":"yongpan_test1"}  #predict


def restart_ers_predict(device_id):
    msg_repredict["deviceID"] = device_id
    ers_task.apply_async(kwargs=msg_repredict, queue='ers_task', serializer='json')


def restart_mrs_predict(device_id):
    msg_repredict["deviceID"] = device_id
    mrs_task.apply_async(kwargs=msg_repredict, queue='mrs_task', serializer='json')


def mrs_retrain(device_id):
    msg_retraining["deviceID"] = device_id
    mrs_task.apply_async(kwargs=msg_retraining, queue='mrs_task', serializer='json')
# mrs_task.delay(json.dumps(msg1))
# mrs_task.delay(json.dumps(msg2))
# class CeleryClient(object):
#     def __init__(self, broker):
#         self.app = Celery('celery_server', broker='redis://172.30.3.123:6379/0')
#
#         @self.app.task(name='ers_task')
#         def ers_task(msg):
#             pass
#
#         @self.app.task(name='mrs_task')
#         def mrs_task(msg):
#             pass
#
#         self.msg_training = {"type": 1, "deviceID": "12334", "taskID": "999999999"}  # training
#         self.msg_predict = {"type": 0, "deviceID": "yongpan_test1"}  # predict
#
#     def restart_training(self):
#         mrs_task.delay(json.dumps(msg1))
#
#         ers_task.delay(json.dumps(msg2))
#         #
        # mrs_task.delay(json.dumps(msg2))

