#!/usr/bin/env python
# @Filename: client_worker.py
# @Author: huayp
# @Date: 2017-11-28 19:01
# -*- coding: utf-8 -*-

from celery import Celery
from lib.github.github_operate import GitHubOperate
import lib.constants.server_info as server_info
import subprocess

backend_url = 'redis://:' + server_info.redis_passwd + '@' + server_info.server_ip + ':6379/1'
broker_url = 'redis://:' + server_info.redis_passwd + '@' + server_info.server_ip + ':6379/0'

app = Celery('client_worker', backend=backend_url , broker=broker_url)


@app.task
def scenario_execute(command):
    print(command)

    process = subprocess.Popen(command, universal_newlines=True, stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT)
    input_str = None
    if 'pscp' in command:
        input_str = 'y'
    return process.communicate(input=input_str)[0].strip()

@app.task
def update_itm_automators():
    updater = GitHubOperate(repo_path="C:\\ITM_Automators",
                            branch_name="huayp")
    updater.pull()
    print("Update ITM Automators")

# This func is for testing
@app.task
def add(x, y):
    return x + y