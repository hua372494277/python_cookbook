#!/usr/bin/env python
# @Filename: server_info.py
# @Author: huayp
# @Date: 2017-12-07 10:14
# -*- coding: utf-8 -*-

# The constants in this file are the info of the server, where ITM_Automators controller is running
server_username = 'huab'
server_ip= '172.30.5.25'
server_passwd = 'Hello123!'
redis_passwd = 'Hello123!'
