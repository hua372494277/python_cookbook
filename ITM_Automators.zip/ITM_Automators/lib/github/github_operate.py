#!/usr/bin/env python
# @Filename: github_operate
# @Author: huayp
# @Date: 2017-11-20 14:19
# -*- coding: utf-8 -*-

import tempfile
import os.path
import subprocess
import random
import string
import uuid

class GitHubOperate(object):
    def __init__(self, repo_path = "", branch_name=""):
        self.repository = "ITM_test"
        self.username = "skyguardTest"
        self.passwd = "skyguardTest123"
        self.char_map = string.ascii_letters + string.digits

        if branch_name:
            self.branchname = branch_name
        else:
            self.branchname = 'master'

        if repo_path:
            self.repo_path = repo_path
        else:
            self.repo_path = tempfile.gettempdir()
            if os.path.exists(os.path.join(self.repo_path, 'ITM_test')):
                self.repo_path = os.path.join(self.repo_path, 'ITM_test')
                print("%s repository is existing" % self.repository)
                self.pull()
            else:
                self.config_name()
                self.config_email()
                self.httpSSl(False)
                self.clone()
                self.repo_path = os.path.join(self.repo_path, 'ITM_test')

        self.filename = ''




        print("The repo path is ", self.repo_path)

    def execute_operation(self, commands):
        print(commands)
        process = subprocess.Popen(commands,
                                   cwd= self.repo_path,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT)
        resp = str(process.communicate()[0])

        if 'unable to access' in resp and '502' in resp:
            print(resp)
            print("Try again.")
            process = subprocess.Popen(commands,
                                       cwd=self.repo_path,
                                       stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT)
            resp = str(process.communicate()[0])

        if 'fail' in resp or 'error' in resp:
            raise AssertionError('Github Error %s' % resp)

    def clone(self):
        cmd = ['git', 'clone', 'https://github.com/skyguardTest/ITM_test.git']
        self.execute_operation(cmd)


    def pull(self):
        cmd = ['git', 'pull', 'origin', self.branchname]
        self.execute_operation(cmd)

    def push(self):
        cmd = ['git','push', 'origin', self.branchname]
        self.execute_operation(cmd)


    def delete_random_file(self):
        cmd = ['git', 'rm', self.filename]
        self.execute_operation(cmd)


    def add(self):
        cmd = ['git', 'add', self.filename]
        self.execute_operation(cmd)

    def commit(self):
        cmd = ['git', 'commit', '-m', 'modify the file for test ' + self.filename]
        self.execute_operation(cmd)

    # Write some random characters into
    # a file named with a random filename (10 chars)
    # Otherwise, the files are conflicted between several hosts

    def write_one_random_file(self):
        # TODO (huayp): the func of generating one random file could use the func in file_operator
        self.filename = str(uuid.uuid1())
        for i in range(0, 10):
            self.filename = self.filename + string.ascii_letters[random.randint(0, 51)]

        print(self.filename)
        # write char_count characters into README.md
        char_count = random.randint(1000, 5000)
        with open(os.path.join(self.repo_path, self.filename), "w") as fw_random_file:
            for i in range(0, char_count):
                fw_random_file.write( self.char_map[ random.randint(0, len(self.char_map) - 1)] )
                if random.randint(0,1):
                    fw_random_file.write("\n")

    def httpSSl(self, verify):
        cmd = ['git', 'config', '--global']
        if not verify:
            cmd.append('http.sslVerify')
            cmd.append('false')
            self.execute_operation(cmd)

    def config_name(self):
        cmd = ['git', 'config', '--global', 'user.name', 'skyguardTest']
        self.execute_operation(cmd)

    def config_email(self):
        cmd = ['git', 'config', '--global', 'user.email', 'huayongpan@skyguard.com.cn']
        self.execute_operation(cmd)

    def create_branch(self):
        self.branchname = str(uuid.uuid1())
        cmd = ['git', 'branch', self.branchname]
        self.execute_operation(cmd)

    def delete_branch(self):
        cmd = ['git', 'push', 'origin', '--delete', self.branchname]
        self.execute_operation(cmd)


if __name__ == '__main__':
    github_operator = GitHubOperate()
    github_operator.create_branch()
    github_operator.write_one_random_file()
    github_operator.add()
    github_operator.commit()
    github_operator.push()
    github_operator.delete_random_file()
    github_operator.push()
    github_operator.delete_branch()
