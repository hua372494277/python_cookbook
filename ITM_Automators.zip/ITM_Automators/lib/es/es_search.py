#!/usr/bin/env python
# @Filename: es_search.py
# @Author: huayp
# @Date: 2017-10-24 10:15
# -*- coding: utf-8 -*-

from abc import ABCMeta, abstractmethod
from elasticsearch import Elasticsearch
from elasticsearch import helpers

'''
This class ESSearch will:
    connect to ES
    set the searching quary and search
    get the hit results and verify

When init one instance, it requires the es server ip and port, 
user name and password
'''
class ESSearch(metaclass=ABCMeta):
    def __init__(self, es_server_ip = "",
                       es_server_port = 0,
                       es_server_username = "admin",
                       es_server_passwd = "password",
                ):
        self.es_server = Elasticsearch([{"host": es_server_ip, "port": int(es_server_port)}],
                   http_auth=(es_server_username, es_server_passwd))

    '''
    Search the logs
    '''
    @abstractmethod
    def search(self, **kwargs):
        pass

    def get_result_list(self, es_result):
        final_result = []
        for item in es_result:
            final_result.append(item['_source'])

        return final_result

    def get_search_result(self, es_search_options, index, scroll='2m', timeout="1m"):
        es_result = helpers.scan(
            client=self.es_server,
            query=es_search_options,
            scroll=scroll,
            index=index,
            timeout=timeout
        )
        return es_result
