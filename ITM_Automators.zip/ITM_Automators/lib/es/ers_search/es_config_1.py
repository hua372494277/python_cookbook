#!/usr/bin/env python
# @Filename: es_config.py
# @Author: huayp
# @Date: 2017-11-16 17:32
# -*- coding: utf-8 -*-

data = {"deviceID": "6b335f1c-b924-8e7e-1b8f-2b436c78b1c7",
          "deviceName": "ucss",
          "itmConfigs": {
          "ers": {
              "interval": 7200,
              "ChosenModels": [
                "fd4d8c8b-35ba-498d-bb41-a4c0bc8f325a",
                "74b5d421-09c5-49ba-ba94-fbbe954f64b5",
                "3b717d0b-2c00-4857-9b3b-eb5bb3563fce",
                "d947b2d2-7ed2-40fe-9456-34b37d709467",
                "def6d838-58bc-4bb4-93fb-66fc90a8061d",
                "17e02e9c-0e6b-4515-ab68-5289c300236c",
                "56fb56bd-6fe4-4b96-a490-8b7e6793d735"
              ],
              "modelParameterMap": [
                {
                  "modelID": "fd4d8c8b-35ba-498d-bb41-a4c0bc8f325a",
                  "parameterMap": [
                    {
                      "parameterID": "5cbb7c50-df10-440f-92a6-ca0d59bad896",
                      "policyIDs": [
                        "75d3db61-61e6-476d-a32c-c336630c6d5b",
                        "5cd2d682-171a-45b7-888a-78286c113aa7"
                      ]
                    }
                  ]
                },
                {
                  "modelID": "74b5d421-09c5-49ba-ba94-fbbe954f64b5",
                  "parameterMap": [
                    {
                      "parameterID": "2e3bec1e-84de-403f-b523-9b0f71cf73d7",
                      "policyIDs": [
                        "689a80b4-cc24-4f4c-95cf-63f9c12441ad",
                        "d59fbb85-26b6-4d86-8a76-86587db356ff",
                        "6cadfe1a-35aa-49a6-b7eb-19bfe49b9bbd",
                        "2c949b49-1008-41d6-9712-ab0eacfdfbef",
                        "12b79401-0255-4e50-8571-25ad5d8db0e6",
                        "1523ef18-74e1-43e1-a4d4-62158fa9b6fd",
                        "b6d66fbc-af10-401c-ab88-baf9d6307bea",
                        "53b4da47-c20c-434b-96a5-8d5558a00ae1",
                        "37430e41-d060-41bf-ae99-5b92f7f38d85",
                        "06e36a05-3121-4988-bd33-9ed1f29d106c",
                        "75d3db61-61e6-476d-a32c-c336630c6d5b",
                        "5cd2d682-171a-45b7-888a-78286c113aa7",
                        "582536e3-54ad-41c6-979c-0437018bb4ab",
                        "8e2d1942-e5bf-497f-9f5a-20de297c760a",
                        "712fcb0e-a66f-4c86-964e-a2ffba334738",
                        "1c8be850-22a3-44c4-8ded-6f700229ae19",
                        "0a4e95a1-dd6d-49a7-8c53-0f92a791101b"
                      ]
                    },
                    {
                      "parameterID": "f2d5d705-2ff8-468f-957f-ace1121ccf5a",
                      "policyIDs": [
                        "689a80b4-cc24-4f4c-95cf-63f9c12441ad",
                        "d59fbb85-26b6-4d86-8a76-86587db356ff",
                        "6cadfe1a-35aa-49a6-b7eb-19bfe49b9bbd",
                        "2c949b49-1008-41d6-9712-ab0eacfdfbef",
                        "12b79401-0255-4e50-8571-25ad5d8db0e6",
                        "1523ef18-74e1-43e1-a4d4-62158fa9b6fd",
                        "b6d66fbc-af10-401c-ab88-baf9d6307bea",
                        "53b4da47-c20c-434b-96a5-8d5558a00ae1",
                        "37430e41-d060-41bf-ae99-5b92f7f38d85",
                        "06e36a05-3121-4988-bd33-9ed1f29d106c",
                        "75d3db61-61e6-476d-a32c-c336630c6d5b",
                        "5cd2d682-171a-45b7-888a-78286c113aa7",
                        "582536e3-54ad-41c6-979c-0437018bb4ab",
                        "8e2d1942-e5bf-497f-9f5a-20de297c760a",
                        "712fcb0e-a66f-4c86-964e-a2ffba334738",
                        "1c8be850-22a3-44c4-8ded-6f700229ae19",
                        "0a4e95a1-dd6d-49a7-8c53-0f92a791101b"
                      ]
                    },
                    {
                      "parameterID": "5cbb7c50-df10-440f-92a6-ca0d59bad896",
                      "policyIDs": [
                        "689a80b4-cc24-4f4c-95cf-63f9c12441ad",
                        "d59fbb85-26b6-4d86-8a76-86587db356ff",
                        "6cadfe1a-35aa-49a6-b7eb-19bfe49b9bbd",
                        "2c949b49-1008-41d6-9712-ab0eacfdfbef",
                        "12b79401-0255-4e50-8571-25ad5d8db0e6",
                        "1523ef18-74e1-43e1-a4d4-62158fa9b6fd",
                        "b6d66fbc-af10-401c-ab88-baf9d6307bea",
                        "53b4da47-c20c-434b-96a5-8d5558a00ae1",
                        "37430e41-d060-41bf-ae99-5b92f7f38d85",
                        "06e36a05-3121-4988-bd33-9ed1f29d106c",
                        "75d3db61-61e6-476d-a32c-c336630c6d5b",
                        "5cd2d682-171a-45b7-888a-78286c113aa7",
                        "582536e3-54ad-41c6-979c-0437018bb4ab",
                        "8e2d1942-e5bf-497f-9f5a-20de297c760a",
                        "712fcb0e-a66f-4c86-964e-a2ffba334738",
                        "1c8be850-22a3-44c4-8ded-6f700229ae19",
                        "0a4e95a1-dd6d-49a7-8c53-0f92a791101b"
                      ]
                    }
                  ]
                },
                {
                  "modelID": "3b717d0b-2c00-4857-9b3b-eb5bb3563fce",
                  "parameterMap": [
                    {
                      "parameterID": "5cbb7c50-df10-440f-92a6-ca0d59bad896",
                      "policyIDs": [
                        "689a80b4-cc24-4f4c-95cf-63f9c12441ad",
                        "d59fbb85-26b6-4d86-8a76-86587db356ff",
                        "6cadfe1a-35aa-49a6-b7eb-19bfe49b9bbd",
                        "2c949b49-1008-41d6-9712-ab0eacfdfbef",
                        "12b79401-0255-4e50-8571-25ad5d8db0e6",
                        "1523ef18-74e1-43e1-a4d4-62158fa9b6fd",
                        "b6d66fbc-af10-401c-ab88-baf9d6307bea",
                        "53b4da47-c20c-434b-96a5-8d5558a00ae1",
                        "37430e41-d060-41bf-ae99-5b92f7f38d85",
                        "06e36a05-3121-4988-bd33-9ed1f29d106c",
                        "582536e3-54ad-41c6-979c-0437018bb4ab",
                        "8e2d1942-e5bf-497f-9f5a-20de297c760a",
                        "712fcb0e-a66f-4c86-964e-a2ffba334738",
                        "1c8be850-22a3-44c4-8ded-6f700229ae19",
                        "0a4e95a1-dd6d-49a7-8c53-0f92a791101b",
                        "75d3db61-61e6-476d-a32c-c336630c6d5b",
                        "5cd2d682-171a-45b7-888a-78286c113aa7"
                      ]
                    }
                  ]
                },
                {
                  "modelID": "d947b2d2-7ed2-40fe-9456-34b37d709467",
                  "parameterMap": [
                    {
                      "parameterID": "5cbb7c50-df10-440f-92a6-ca0d59bad896",
                      "policyIDs": [
                        "689a80b4-cc24-4f4c-95cf-63f9c12441ad",
                        "d59fbb85-26b6-4d86-8a76-86587db356ff",
                        "6cadfe1a-35aa-49a6-b7eb-19bfe49b9bbd",
                        "2c949b49-1008-41d6-9712-ab0eacfdfbef",
                        "12b79401-0255-4e50-8571-25ad5d8db0e6",
                        "1523ef18-74e1-43e1-a4d4-62158fa9b6fd",
                        "b6d66fbc-af10-401c-ab88-baf9d6307bea",
                        "53b4da47-c20c-434b-96a5-8d5558a00ae1",
                        "37430e41-d060-41bf-ae99-5b92f7f38d85",
                        "06e36a05-3121-4988-bd33-9ed1f29d106c",
                        "582536e3-54ad-41c6-979c-0437018bb4ab",
                        "8e2d1942-e5bf-497f-9f5a-20de297c760a",
                        "712fcb0e-a66f-4c86-964e-a2ffba334738",
                        "1c8be850-22a3-44c4-8ded-6f700229ae19",
                        "0a4e95a1-dd6d-49a7-8c53-0f92a791101b",
                        "75d3db61-61e6-476d-a32c-c336630c6d5b",
                        "5cd2d682-171a-45b7-888a-78286c113aa7"
                      ]
                    }
                  ]
                },
                {
                  "modelID": "def6d838-58bc-4bb4-93fb-66fc90a8061d",
                  "parameterMap": []
                },
                {
                  "modelID": "17e02e9c-0e6b-4515-ab68-5289c300236c",
                  "parameterMap": [
                    {
                      "parameterID": "5cbb7c50-df10-440f-92a6-ca0d59bad896",
                      "policyIDs": [
                        "689a80b4-cc24-4f4c-95cf-63f9c12441ad",
                        "d59fbb85-26b6-4d86-8a76-86587db356ff",
                        "6cadfe1a-35aa-49a6-b7eb-19bfe49b9bbd",
                        "2c949b49-1008-41d6-9712-ab0eacfdfbef",
                        "12b79401-0255-4e50-8571-25ad5d8db0e6",
                        "1523ef18-74e1-43e1-a4d4-62158fa9b6fd",
                        "b6d66fbc-af10-401c-ab88-baf9d6307bea",
                        "53b4da47-c20c-434b-96a5-8d5558a00ae1",
                        "37430e41-d060-41bf-ae99-5b92f7f38d85",
                        "06e36a05-3121-4988-bd33-9ed1f29d106c",
                        "75d3db61-61e6-476d-a32c-c336630c6d5b",
                        "5cd2d682-171a-45b7-888a-78286c113aa7",
                        "582536e3-54ad-41c6-979c-0437018bb4ab",
                        "8e2d1942-e5bf-497f-9f5a-20de297c760a",
                        "712fcb0e-a66f-4c86-964e-a2ffba334738",
                        "1c8be850-22a3-44c4-8ded-6f700229ae19",
                        "0a4e95a1-dd6d-49a7-8c53-0f92a791101b"
                      ]
                    }
                  ]
                },
                {
                  "modelID": "56fb56bd-6fe4-4b96-a490-8b7e6793d735",
                  "parameterMap": []
                }
              ],
              "blacklist": [],
              "topN": 0,
              "version": 16
            },
            "ars": {
              "topN": 0,
              "subsystems": [
                1,
                2,
                3
              ],
              "blacklist": [
                "192.168.1.1",
                "192.168.2.1-192.168.2.32",
                "name123",
                "domain123/name123",
                "domain123/name1*"
              ],
              "interval": 3600,
              "version": 1001
            },
            "mrs": {
              "topN": 0,
              "uploadToLab": True,
              "chosenDLPPolicies": [
                "824a7639-5532-433a-84d7-166363dc0372",
                "0672749d-8442-458b-b131-d7b5270b4d15"
              ],
              "retrospectiveDays": 7,
              "version": 1001,
              "blacklist": [
                "192.168.1.1",
                "192.168.2.1-192.168.2.32",
                "name123",
                "domain123/name123",
                "domain123/name1*"
              ],
              "interval": 3600
            }
          },
          "logSources": [
            "172.22.111.100",
            "172.22.111.110",
            "172.22.111.111"
          ],
          "is_active": True
        }

# a=es.search(index="mrs_results", doc_type="mrs_results", body={"query":{"match_all":{}}},size=1000)
# score=[]
# for i in a['hits']['hits']:
#     score.append(i['_source'])
# score=pd.DataFrame(score)
from elasticsearch import Elasticsearch
es = Elasticsearch([{"host": "172.22.111.250", "port": 9200}],
                   http_auth=("", ""))
es.index(index="itm_configs", doc_type="itm_configs",id="6b335f1c-b924-8e7e-1b8f-2b436c78b1c7", body=data, refresh=True)