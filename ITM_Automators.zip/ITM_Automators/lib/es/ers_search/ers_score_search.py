#!/usr/bin/env python
# @Filename: es_config.py
# @Author: huayp
# @Date: 2017-11-11 14:00
# -*- coding: utf-8 -*-

from lib.es.score_search import ScoreSearch

'''
This class ERSScoreSearch will
get the scores for the provided ip, policyUUID and time
'''


class ERSScoreSearch(ScoreSearch):
    '''
    This functions get_ers_scores do:
    '''
    def get_ers_scores(self, start_time, end_time, trigger_id, trigger_uuid):
        scores=self.get_scores(start_time,end_time, trigger_uuid)
        hit_scores = {}

        for key,value in scores.items():
            if trigger_id in value:
                hit_scores[key] = value[trigger_id]

        return hit_scores



if __name__ == "__main__":
    ers_score_search = ERSScoreSearch(es_server_ip="172.22.73.230",
                               es_server_port=9200,
                               es_server_username="",
                               es_server_passwd="",
                               es_config="ers_results",
                               device_id="497befd3-38a9-a4dc-2123-7cf97f5581b2"
                               )

    ers_scores = ers_score_search.get_ers_scores(start_time="2018-03-01 00:00:00", end_time="2018-03-20 00:00:00",
                                         trigger_id='172.22.1.52', trigger_uuid="fd4d8c8b-35ba-498d-bb41-a4c0bc8f325a")
    print(ers_scores)
    # restart_ers_predict("bad_info_test")

    # ers_search.enable_policy_by_uuid("def6d838-58bc-4bb4-93fb-66fc90a8061d")
    # ers_search.disable_policy_by_uuid("fd4d8c8b-35ba-498d-bb41-a4c0bc8f325a")
    # ers_search.disable_policy_by_uuid("56fb56bd-6fe4-4b96-a490-8b7e6793d735")
    # ers_search.disable_policy_by_uuid("def6d838-58bc-4bb4-93fb-66fc90a8061d")
    # ers_search.disable_policy_by_uuid("d947b2d2-7ed2-40fe-9456-34b37d709467")

    # ers_search = ERSSearch(es_server_ip="172.22.0.60",
    #                        es_server_port=9200,
    #                        es_server_username="admin",
    #                        es_server_passwd="Firewall",
    #                        es_config="ers_results",
    #                        )
    # scores = ers_search.get_ers_scores(start_time="2017-11-16 11:23:53.000", end_time="2017-11-16 11:23:54.000", trigger_id = '172.22.1.52', trigger_uuid = '17e02e9c-0e6b-4515-ab68-5289c300236c')
    # ers_search = ERSSearch(es_server_ip="172.22.0.60",
    #                        es_server_port=9200,
    #                        es_server_username="admin",
    #                        es_server_passwd="Firewall",
    #                        es_config="itm_test_configs",
    #                        device_id="employee_leave_stole_data_test"
    #                        )
    # ers_search.change_time_interval()
    # restart_ers_predict("employee_leave_stole_data_test")