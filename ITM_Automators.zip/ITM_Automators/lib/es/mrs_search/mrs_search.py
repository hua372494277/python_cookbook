#!/usr/bin/env python
# @Filename: mrs_search
# @Author: huayp
# @Date: 2017-12-11 11:04
# -*- coding: utf-8 -*-

from lib.es.score_search import ScoreSearch

'''
'''
class MRSScoreSearch(ScoreSearch):
    '''

    '''




