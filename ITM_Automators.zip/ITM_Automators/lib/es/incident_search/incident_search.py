#!/usr/bin/env python
# @Filename: incident_search.py
# @Author: huayp
# @Date: 2017-11-13 10:56
# -*- coding: utf-8 -*-

from lib.es.es_search import ESSearch
from elasticsearch import Elasticsearch
from elasticsearch import helpers
import datetime

'''
This class IncidentSearch will:
    quary incidentlog
    verify if the expected itms is triggered 

dlp_log_src_ip and trigger_host_ip is for filtering the searching quary.
'''


class IncidentSearch(ESSearch):
    def __init__(self, es_server_ip = "",
                       es_server_port = 0,
                       es_server_username = "admin",
                       es_server_passwd = "password",
                       dlp_log_src_ip = [],
                       trigger_host_ip = []):
        super(self.__class__, self).__init__( es_server_ip = es_server_ip,
                                              es_server_port = int(es_server_port),
                                              es_server_username = es_server_username,
                                              es_server_passwd=es_server_passwd)

        self.dlp_log_src_ip = dlp_log_src_ip
        self.trigger_host_ip = trigger_host_ip

    '''
    Search the logs at the specified time stamp
    Input: 
        start_time: type datetime
        end_time: type datetime
    Output: 
        final_result (list, in which each item is dict, like the following:)
            [
                {
                    '@timestamp': '2017-10-23T10:35:51.000Z', 
                    'sourceIp': '172.22.1.127', 
                    'policyNames': 'ITM安全策略(内置);ITM-02-未知文件类型;ITM-03-SAM文件(Win)或Passwd文件(Lin）;ITM-01-加密文件类型'
                }, 
                {
                    '@timestamp': '2017-10-23T10:35:51.000Z', 
                    'sourceIp': '172.22.1.127', 
                    'policyNames': 'ITM-02-未知文件类型;ITM-03-SAM文件(Win)或Passwd文件(Lin）;ITM-01-加密文件类型'
                }
                ...
            ]
    '''
    def search(self, **kwargs):
        assert "start_time" in kwargs
        assert "end_time" in kwargs
        es_srh_incdt_opts = self.set_search_incident(start_time = datetime.datetime.strptime(kwargs["start_time"], "%Y-%m-%d %H:%M:%S") - datetime.timedelta(hours=8),
                                                     end_time = datetime.datetime.strptime(kwargs["end_time"], "%Y-%m-%d %H:%M:%S") - datetime.timedelta(hours=8))

        es_result = self.get_search_result(es_srh_incdt_opts, index="incidentlog-*")
        final_result = self.get_result_list(es_result)
        return final_result


    '''
    Input:
        start_time, end_time format: (preferred) "2017-10-23 18:35:00"
        dlp_log_src_ip type list
        trigger_host_ip type list
    '''
    def set_search_incident(self, **kwargs):
        assert "start_time" in kwargs
        start_time = kwargs['start_time']
        assert "end_time" in kwargs
        end_time = kwargs['end_time']

        es_search_options = {
            "query": {
                "bool": {
                    "filter": {
                        "bool": {
                            "must": [
                                {
                                    "range": {
                                        "@timestamp": {
                                            "gt": str(start_time.year) + "-" + '%02d' % (start_time.month) + "-" + '%02d' % (
                                            start_time.day) + "T" + '%02d' % (start_time.hour) + ":" + '%02d' % (
                                            start_time.minute) + ":" + '%02d' % (start_time.second) + ".000Z",
                                            "lt": str(end_time.year) + "-" + '%02d' % (end_time.month) + "-" + '%02d' % (
                                            end_time.day) + "T" + '%02d' % (end_time.hour) + ":" + '%02d' % (
                                            end_time.minute) + ":" + '%02d' % (end_time.second) + ".000Z",
                                        }
                                    }
                                },
                                {
                                    "terms": {"deviceID.keyword": self.dlp_log_src_ip}
                                },
                                {
                                    "terms": {"sourceIp": self.trigger_host_ip}
                                }
                            ]
                        }
                    }
                }
            },
            "_source": ["@timestamp", "policyUuids", "sourceIp"]
        }
        return es_search_options

    '''
    Check if the expected ITM strategies have been triggered.
        time stamp format: "2017-10-23 18:35:00"        
    '''
    def verify_itm_triggered(self, start_time, end_time, trigger_itms = []):
        final_result = self.search(start_time=start_time,
                                   end_time=end_time)

        for rec in final_result:
            triggered_one_itm = True
            for itm in trigger_itms:
                if 'policyUuids' in rec and itm.lower() in rec['policyUuids'].lower():
                    continue
                else:
                    triggered_one_itm = False
                    break

            if triggered_one_itm:
                return True
        return False

if __name__ == "__main__":
    incidt_search = IncidentSearch(es_server_ip = "172.22.111.250",
                       es_server_port = 9200,
                       es_server_username = "",
                       es_server_passwd = "",
                       dlp_log_src_ip = ["6b335f1c-b924-8e7e-1b8f-2b436c78b1c7"],
                       trigger_host_ip = ["172.22.1.127"])
    # incidt_search.search(start_time = "2017-10-25 07:05:00", end_time="2017-10-25 08:11:00")
    incidt_search.verify_itm_triggered(start_time="2017-12-13 17:43:00", end_time="2017-12-13 17:46:11", trigger_itms=["5cd2d682-171a-45b7-888a-78286c113aa7","75d3db61-61e6-476d-a32c-c336630c6d5b"])