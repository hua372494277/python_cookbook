#!/usr/bin/env python
# @Filename: itm_config
# @Author: huayp
# @Date: 2017-12-12 11:29
# -*- coding: utf-8 -*-


#!/usr/bin/env python
# @Filename: score_search
# @Author: huayp
# @Date: 2017-12-12 10:56
# -*- coding: utf-8 -*-

from lib.es.es_search import ESSearch
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from lib.celery.celery_client import restart_ers_predict, restart_mrs_predict, mrs_retrain

import datetime

'''
This class ScoreSearch only deal with mrs_results/ers_results
get the scores 
'''


class ITMConfig(ESSearch):
    def __init__(self, es_server_ip = "",
                       es_server_port = 0,
                       es_server_username = "admin",
                       es_server_passwd = "password",
                       es_config = "itm_test_configs",  # ers_
                       device_id = "6b335f1c-b924-8e7e-1b8f-2b436c78b1c7",  #
                       ):
        super(ITMConfig, self).__init__(es_server_ip = es_server_ip,
                                        es_server_port = int(es_server_port),
                                        es_server_username = es_server_username,
                                        es_server_passwd=es_server_passwd)

        self.es_config = es_config
        self.doc_type = None
        self.device_id = device_id
        self.id = None
        self.source  = None

    def set_search_interval_options(self):
        interval_options = {
            "query":{
                "bool":{
                    "filter":{
                        "bool":{
                            "must":[
                                {
                                    "match":{
                                        "deviceID": self.device_id
                                    }
                                }
                            ]
                        }
                  }
                }
            }
        }
        return interval_options

    def get_interval(self):
        scores_options = self.set_search_itm_config()
        results = self.search(search_options = scores_options)
        assert results['hits']['total'] == 1
        hits = results['hits']['hits'][0]
        self.doc_type = hits['_type']
        self.id = hits['_id']
        self.source = hits['_source']


    def set_search_itm_config(self):
        es_search_options = {
            "query": {
                "match": {
                    "deviceID": self.device_id
                }
            }
        }
        return es_search_options


    '''
    search function will send the followings REST to ES.
    GET itm_test_configs/_search
    {
      "query":{
        "match":{
          "deviceID":"yongpan_test1"
        }
      }
    }
    The output is too long. So it could be seen in Kibana. 
    '''
    def search(self, **kwargs):
        assert "search_options" in kwargs
        results = self.es_server.search(index=self.es_config, body=kwargs["search_options"])
        return results


    def get_current_chosen_policies(self):
        self.get_ers_config()
        ers_chosen_models = self.source['itmConfigs']['ers']['ChosenModels']
        return ers_chosen_models

    def enable_policy_by_uuid(self, policy_uuid):
        ers_chosen_models = self.get_current_chosen_policies()

        if policy_uuid not in ers_chosen_models:
            ers_chosen_models.append(policy_uuid)
            self.es_server.index(index=self.es_config,
                                 doc_type = self.doc_type,
                                 id=self.id,
                                 body=self.source,
                                 refresh=True)

        restart_ers_predict(self.device_id)

    def disable_policy_by_uuid(self, policy_uuid):
        ers_chosen_models = self.get_current_chosen_policies()

        for i in range(len(ers_chosen_models)):
            if ers_chosen_models[i] == policy_uuid:
                del ers_chosen_models[i]
                self.es_server.index(index=self.es_config,
                                     doc_type=self.doc_type,
                                     id=self.id,
                                     body=self.source,
                                     refresh=True)
                restart_ers_predict(self.device_id)
                return

    '''
    This function add_new_device_id does:
    1 get the config from that one existing as template
    2 change the device id to the parameter
    3 index the new device id's config   
    '''
    def add_new_device_id(self, device_id):
        # TODO (huayp): this function has not been tested since many device ids will make ES complex.
        # It won't benefit to test at the beginning.

        self.get_ers_config()
        self.source['deviceID'] = device_id

        self.es_server.index(index=self.es_config,
                             doc_type=self.doc_type,
                             body=self.source,
                             refresh=True)

    '''
    This functions get_ers_scores do:
    '''
    def get_ers_scores(self, start_time, end_time, trigger_id, trigger_uuid):
        ers_scores_options = self.set_search_ers_scores_options(start_time = datetime.datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S") - datetime.timedelta(minutes=2),
                                                                end_time = datetime.datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S") + datetime.timedelta(minutes=2),
                                                                trigger_uuid=trigger_uuid)

        results = self.search(search_options=ers_scores_options)
        scores={}
        for rec in results['hits']['hits']:
            score_dict = eval(rec['_source']['scores'])
            if trigger_id in score_dict:
                scores[rec['_source']["timestamp"]] = score_dict[trigger_id]

        return scores


    def set_search_ers_scores_options(self, start_time, end_time, trigger_uuid):
        ers_scores_options = {
            "query": {
                "bool": {
                    "filter": {
                        "bool": {
                            "must": [
                                {
                                    "match": {
                                        "deviceID": self.device_id
                                    }
                                },
                                {
                                    "match": {
                                        "policyID": trigger_uuid
                                    }
                                },
                                {
                                    "range": {
                                        "timestamp": {
                                            "gt": str(start_time.year) + "-" + '%02d' % (start_time.month) + "-" + '%02d' % (
                                            start_time.day) + "T" + '%02d' % (start_time.hour) + ":" + '%02d' % (
                                            start_time.minute) + ":" + '%02d' % (start_time.second) + "+0800",
                                            "lt": str(end_time.year) + "-" + '%02d' % (end_time.month) + "-" + '%02d' % (
                                            end_time.day) + "T" + '%02d' % (end_time.hour) + ":" + '%02d' % (
                                            end_time.minute) + ":" + '%02d' % (end_time.second) + "+0800",
                                        }
                                    }
                                }
                            ]
                        }
                    }
                }
            }
        }

        return ers_scores_options

    def set_parameter_map(self):
        # TODO (huayp): change the chosen models and update the parameter maps
        pass

    def get_time_interval(self):
        self.get_ers_config()
        ers_interval = self.source['itmConfigs']['ers']['interval']
        return ers_interval

    def change_time_interval(self):
        self.get_ers_config()
        ers_interval = self.source['itmConfigs']['ers']['interval']

        if ers_interval == 3600:
            self.source['itmConfigs']['ers']['interval'] = 3599
        else:
            self.source['itmConfigs']['ers']['interval'] = 3600

        self.es_server.index(index=self.es_config,
                             doc_type=self.doc_type,
                             id=self.id,
                             body=self.source,
                             refresh=True)

        restart_ers_predict(self.device_id)

if __name__ == "__main__":
    ers_search = ERSSearch(es_server_ip="172.22.0.60",
                           es_server_port=9200,
                           es_server_username="admin",
                           es_server_passwd="Firewall",
                           es_config="itm_configs",
                           device_id=""
                           )
    ers_search.change_time_interval()
    # restart_ers_predict("bad_info_test")

    # ers_search.enable_policy_by_uuid("def6d838-58bc-4bb4-93fb-66fc90a8061d")
    # ers_search.disable_policy_by_uuid("fd4d8c8b-35ba-498d-bb41-a4c0bc8f325a")
    # ers_search.disable_policy_by_uuid("56fb56bd-6fe4-4b96-a490-8b7e6793d735")
    # ers_search.disable_policy_by_uuid("def6d838-58bc-4bb4-93fb-66fc90a8061d")
    # ers_search.disable_policy_by_uuid("d947b2d2-7ed2-40fe-9456-34b37d709467")

    # ers_search = ERSSearch(es_server_ip="172.22.0.60",
    #                        es_server_port=9200,
    #                        es_server_username="admin",
    #                        es_server_passwd="Firewall",
    #                        es_config="ers_results",
    #                        )
    # scores = ers_search.get_ers_scores(start_time="2017-11-16 11:23:53.000", end_time="2017-11-16 11:23:54.000", trigger_id = '172.22.1.52', trigger_uuid = '17e02e9c-0e6b-4515-ab68-5289c300236c')
    # ers_search = ERSSearch(es_server_ip="172.22.0.60",
    #                        es_server_port=9200,
    #                        es_server_username="admin",
    #                        es_server_passwd="Firewall",
    #                        es_config="itm_test_configs",
    #                        device_id="employee_leave_stole_data_test"
    #                        )
    # ers_search.change_time_interval()
    # restart_ers_predict("employee_leave_stole_data_test")