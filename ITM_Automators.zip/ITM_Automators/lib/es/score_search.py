#!/usr/bin/env python
# @Filename: score_search
# @Author: huayp
# @Date: 2017-12-12 10:56
# -*- coding: utf-8 -*-

from lib.es.es_search import ESSearch
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from lib.celery.celery_client import restart_ers_predict, restart_mrs_predict, mrs_retrain

import datetime

'''
This class ScoreSearch only deal with mrs_results/ers_results
get the scores 
'''


class ScoreSearch(ESSearch):
    def __init__(self, es_server_ip = "",
                       es_server_port = 0,
                       es_server_username = "admin",
                       es_server_passwd = "password",
                       es_config = "itm_test_configs",  # ers_
                       device_id = "6b335f1c-b924-8e7e-1b8f-2b436c78b1c7",  #
                       ):
        super(ScoreSearch, self).__init__( es_server_ip = es_server_ip,
                                              es_server_port = int(es_server_port),
                                              es_server_username = es_server_username,
                                              es_server_passwd=es_server_passwd)

        self.es_config = es_config
        self.doc_type = None
        self.device_id = device_id
        self.id = None
        self.source  = None

        # self.all_ers_policies_uuids = ["fd4d8c8b-35ba-498d-bb41-a4c0bc8f325a",
        #           "d947b2d2-7ed2-40fe-9456-34b37d709467",
        #           "74b5d421-09c5-49ba-ba94-fbbe954f64b5",
        #           "def6d838-58bc-4bb4-93fb-66fc90a8061d",
        #           "3b717d0b-2c00-4857-9b3b-eb5bb3563fce",
        #           "17e02e9c-0e6b-4515-ab68-5289c300236c",
        #           "56fb56bd-6fe4-4b96-a490-8b7e6793d735"]


    '''
    search function will send the followings REST to ES.
    GET itm_test_configs/_search
    {
      "query":{
        "match":{
          "deviceID":"yongpan_test1"
        }
      }
    }
    The output is too long. So it could be seen in Kibana. 
    '''
    def search(self, **kwargs):
        assert "search_options" in kwargs
        results = self.es_server.search(index=self.es_config, body=kwargs["search_options"])
        return results


    '''
    This functions get_ers_scores do:
    '''
    def get_scores(self, start_time, end_time, trigger_uuid):
        scores_options = self.set_search_scores_options(start_time = datetime.datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S") - datetime.timedelta(minutes=2),
                                                                end_time = datetime.datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S") + datetime.timedelta(minutes=2),
                                                                trigger_uuid=trigger_uuid)

        results = self.search(search_options=scores_options)
        scores={}
        for rec in results['hits']['hits']:
            score_dict = eval(rec['_source']['scores'])
            scores[rec['_source']["timestamp"]] = score_dict
        return scores


    def set_search_scores_options(self, start_time, end_time, trigger_uuid):
        scores_options = {
            "query": {
                "bool": {
                    "filter": {
                        "bool": {
                            "must": [
                                {
                                    "match": {
                                        "deviceID": self.device_id
                                    }
                                },
                                {
                                    "match": {
                                        "policyID": trigger_uuid
                                    }
                                },
                                {
                                    "range": {
                                        "timestamp": {
                                            "gt": str(start_time.year) + "-" + '%02d' % (start_time.month) + "-" + '%02d' % (
                                            start_time.day) + "T" + '%02d' % (start_time.hour) + ":" + '%02d' % (
                                            start_time.minute) + ":" + '%02d' % (start_time.second) + "+0800",
                                            "lt": str(end_time.year) + "-" + '%02d' % (end_time.month) + "-" + '%02d' % (
                                            end_time.day) + "T" + '%02d' % (end_time.hour) + ":" + '%02d' % (
                                            end_time.minute) + ":" + '%02d' % (end_time.second) + "+0800",
                                        }
                                    }
                                }
                            ]
                        }
                    }
                }
            }
        }

        return scores_options

    def set_parameter_map(self):
        # TODO (huayp): change the chosen models and update the parameter maps
        pass


if __name__ == "__main__":
    score_search = ScoreSearch(es_server_ip="172.22.111.250",
                           es_server_port=9200,
                           es_server_username="",
                           es_server_passwd="",
                           es_config="ers_results",
                           device_id="PR1710G316050012"
                           )
    mrs_scores = score_search.get_scores(start_time="2018-03-02 18:00:00", end_time="2018-03-02 18:00:00", trigger_uuid="17e02e9c-0e6b-4515-ab68-5289c300236c")

    # score_search = ScoreSearch(es_server_ip="172.22.111.250",
    #                        es_server_port=9200,
    #                        es_server_username="",
    #                        es_server_passwd="",
    #                        es_config="ers_results",
    #                        device_id="6b335f1c-b924-8e7e-1b8f-2b436c78b1c7"
    #                        )
    # ers_scores = score_search.get_scores(start_time="2017-12-09 00:00:00", end_time="2017-12-12 00:00:00",
    #                                      trigger_uuid="fd4d8c8b-35ba-498d-bb41-a4c0bc8f325a")
    #
    print(mrs_scores)
