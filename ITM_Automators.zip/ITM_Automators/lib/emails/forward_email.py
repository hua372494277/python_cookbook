#!/usr/bin/env python
# @Filename: forward_action.py
# @Author: huayp
# @Date: 2017-10-21 10:18
# -*- coding: utf-8 -*-

'''
This Class only do decorate the email
for making it like a forwarded email.

For forwarding emails, it only overrides the get_subject
 function to add "Fw:" in subject.

 Changing the content is for adding more comments.
 So it is easier to see this email is forwarding one.
'''
from lib.emails.decorate_email import DecorateEmail

class ForwardEmail(DecorateEmail):
    # Add "Fw:" to subject so that the email becomes
    # a forwarded email
    def get_subject(self):
        return "Fw:" + self.email_encaped.get_subject()

    def get_content(self):
        return self.email_encaped.get_content() + \
               "_Forwarding..."


if __name__ == "__main__":
    from lib.emails.normal_email import NormalEmail
    forward_eml = ForwardEmail(NormalEmail())
    print("Subject: ", forward_eml.get_subject())
    print("To Emails: ", forward_eml.get_to_emails())
    print("Bcc Emails: ", forward_eml.get_bcc_emails())
    print("Content: ", forward_eml.get_content())
    print("To and Bcc Emails: ", forward_eml.get_to_and_bccs())

    forward_eml = ForwardEmail(forward_eml)
    print("Subject: ", forward_eml.get_subject())
    print("To Emails: ", forward_eml.get_to_emails())
    print("Bcc Emails: ", forward_eml.get_bcc_emails())
    print("Content: ", forward_eml.get_content())
    print("To and Bcc Emails: ", forward_eml.get_to_and_bccs())

