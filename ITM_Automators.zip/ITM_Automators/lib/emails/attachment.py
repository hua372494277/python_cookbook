#!/usr/bin/env python
# @Filename: attachment
# @Author: huayp
# @Date: 2017-10-20 17:54
# -*- coding: utf-8 -*-

'''
This class is to read file to attachment
And convert to MIMEApplication type
Which could be supported in MIMEMultipart
'''
from email.mime.application import MIMEApplication
import os

class Attachment(object):
    def __init__(self, paths):
        self.attachs = []
        for path in paths:
            att = MIMEApplication(open(path, 'rb').read())
            att.add_header('Content-Disposition', 'attachment', filename=os.path.basename(path))
            self.attachs.append(att)