#!/usr/bin/env python
# @Filename: bcc_email
# @Author: huayp
# @Date: 2017-10-21 14:24
# -*- coding: utf-8 -*-

from lib.emails.decorate_email import DecorateEmail
import copy

'''
This class only decorates the email
 for making it like a blind carbon copy email.
 It overrides the get_bcc_emails() and get_to_and_bccs(),
 and re-set bcc_emails and to_and_bccs in __init__ functions.
 
 Since blind carbon copy email has some bcc email addresses, 
 so bcc emails should be not empty. And to_and_bccs should combine
 to email and bcc email addresses together.
'''
class BCCEmail(DecorateEmail):
    def __init__(self, email_encap, bcc_emails=[]):
        super(BCCEmail, self).__init__(email_encap)

        self.bcc_emails = copy.copy(self.email_encaped.get_bcc_emails())
        self.to_and_bccs = copy.copy(self.email_encaped.get_to_and_bccs())

        if bcc_emails != []:
            for bcc_eml in bcc_emails:
                if bcc_eml not in self.bcc_emails:
                    self.bcc_emails.append(bcc_eml)
                    self.to_and_bccs.append(bcc_eml)

        self.is_bcced()


    def get_bcc_emails(self):
        return self.bcc_emails

    '''
    is_bcced() is to verify if bcc_emails is empty,
    and make sure bcc email address should be not same with
    to email addresses.
    '''
    def is_bcced(self):
        if len(self.get_bcc_emails()) == 0:
            raise AssertionError("Bcc emails are empty, but they are required.")

        for bcc_email in self.get_bcc_emails():
            if bcc_email in self.get_to_emails():
                raise AssertionError("Bcc email should not be also in To email lists")

    def get_to_and_bccs(self):
        return self.to_and_bccs

    def get_content(self):
        return self.email_encaped.get_content() + \
               "_Bccing..."


if __name__ == "__main__":
    from lib.emails.normal_email import NormalEmail
    bcc_email = BCCEmail(NormalEmail(bcc_emails=["huayp@outlook.com"]))
    print("Subject: ", bcc_email.get_subject())    
    print("To Emails: ", bcc_email.get_to_emails())
    print("Bcc Emails: ", bcc_email.get_bcc_emails())
    print("Content: ", bcc_email.get_content())
    print("To and Bcc Emails", bcc_email.get_to_and_bccs())

    # If not provide more new bcc email list
    # The following step will fail
    bcc_email = BCCEmail(bcc_email, bcc_emails=["aa@qq.com"])
    print("----------------")
    print("Subject: ", bcc_email.get_subject())    
    print("To Emails: ", bcc_email.get_to_emails())
    print("Bcc Emails: ", bcc_email.get_bcc_emails())
    print("Content: ", bcc_email.get_content())
    print("To and Bcc Emails", bcc_email.get_to_and_bccs())

    from lib.emails.forward_email import ForwardEmail
    print("------Forwarding------")
    forward_eml = ForwardEmail(bcc_email)
    print("Subject: ", forward_eml.get_subject())
    print("To Emails: ", forward_eml.get_to_emails())
    print("Bcc Emails: ", forward_eml.get_bcc_emails())
    print("Content: ", forward_eml.get_content())
    print("To and Bcc Emails: ", forward_eml.get_to_and_bccs())


    print("--------Bcc again-------")
    bcc_email = BCCEmail(forward_eml, bcc_emails=["aabb@qq.com"])
    print("----------------")
    print("Subject: ", bcc_email.get_subject())    
    print("To Emails: ", bcc_email.get_to_emails())
    print("Bcc Emails: ", bcc_email.get_bcc_emails())
    print("Content: ", bcc_email.get_content())
    print("To and Bcc Emails", bcc_email.get_to_and_bccs())