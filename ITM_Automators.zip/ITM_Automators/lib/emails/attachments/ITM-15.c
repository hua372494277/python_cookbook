#include "isic.h"


int
main(int argc, char **argv)
{
	int c, frag_flag = 0, dstopt_flag = 0;
	u_char *buf = NULL;
	u_short	*payload = NULL;
	u_int payload_s = 0;
	int packet_len = 0, dstopt_tlen = 0;
	char addrbuf[INET6_ADDRSTRLEN];

	/* libnet variables */
	char errbuf[LIBNET_ERRBUF_SIZE];
	libnet_t *l;
	char *device = NULL;

	/* Packet Variables */
	u_int src_addr_flag = 0, dst_addr_flag = 0;
	u_char ver, hlim, nxt;
	u_int16_t plen;
	u_int32_t flow;
	struct ip6_hdr *ip6 = NULL;
	struct libnet_in6_addr src_addr;
	struct libnet_in6_addr dst_addr;

	struct tcphdr *tcp = NULL;
	u_short src_prt = 0, dst_prt = 0;

	struct ip6_frag *ip6_fraghdr = NULL; /* IPv6 fragment header */
	u_char f6_nxt = 0, f6_rsv = 0;
	u_int32_t f6_id = 0;
	u_int16_t f6_offlg = 0;

	struct ip6_dest *ip6_dopthdr = NULL; /* IPv6 destination option header */
	u_char dstopt_nxt = 0, dstopt_len = 0;
}