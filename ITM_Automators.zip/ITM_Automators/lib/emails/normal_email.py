#!/usr/bin/env python
# @Filename: normal_email.py
# @Author: huayp
# @Date: 2017-10-21 15:45
# -*- coding: utf-8 -*-

from lib.emails.emails import Email
'''
This class is to create one normal email.
It could simulate the normal behavior.
But also, it could be encapsulated by ForwardEmail and BCCEmail classes,
so that creating one forwarded email or bcced email by this way:
forwarded_email = ForwardEmail(NormalEmail())
bcced_email = BCCEmail(NormalEmail())
'''
class NormalEmail(Email):
    def __init__(self, subject="ITM System Test Email",
                       to_emails=[],
                       bcc_emails=[],
                       content="This email is to test ITM System",
                       attachment_paths=[]
                       ):
        self.subject = subject
        self.to_emails = to_emails
        self.bcc_emails = []
        self.content = content
        self.attachment_paths = attachment_paths
        # Usually, destination emails are same as To emails
        # But when want to bcc emails to someones
        # dst emails will combine To emails and bcc emails
        self.tos_and_bccs = to_emails + bcc_emails

    def get_subject(self):
        return self.subject

    # def get_from_email(self):
    #     return self.from_email
    def get_to_emails(self):
        return self.to_emails

    # Usually, the normal email could be sent
    # by bcc
    def get_bcc_emails(self):
        return self.bcc_emails

    def get_content(self):
        return self.content + "_Create_Email..."

    def get_attachment_path(self):
        return self.attachment_paths

    def get_to_and_bccs(self):
        return self.tos_and_bccs


if __name__ == "__main__":
    normal_eml = NormalEmail()
    print(normal_eml.get_subject())
    print(normal_eml.get_to_emails())
    print(normal_eml.get_bcc_emails())
    print(normal_eml.get_content())
    print(normal_eml.get_attachment_path())
    print(normal_eml.get_to_and_bccs())
