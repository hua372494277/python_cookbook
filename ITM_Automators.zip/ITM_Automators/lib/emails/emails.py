#!/usr/bin/env python
# @Filename: email
# @Author: huayp
# @Date: 2017-10-20 16:07
# -*- coding: utf-8 -*-

from abc import ABCMeta, abstractmethod
'''
This class is an abstract class
It only defines the interfaces, which will be used by
normal emails, forwarded and bcced emails.
Forwarded: the email could be forwarded out.
Bcced: the email could be blind carbon copied out.

For Since all actions including forwarding, bcc, attaching files,
could be nested into many levels.
So using decorator design pattern here
'''
class Email(metaclass=ABCMeta):
    @abstractmethod
    def get_subject(self):
        pass

    @abstractmethod
    def get_to_emails(self):
        pass

    @abstractmethod
    def get_bcc_emails(self):
        pass

    @abstractmethod
    def get_content(self):
        pass

    @abstractmethod
    def get_attachment_path(self):
        pass

    @abstractmethod
    def get_to_and_bccs(self):
        pass