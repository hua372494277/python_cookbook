#!/usr/bin/env python
# @Filename: SMTPEmail.py
# @Author: huayp
# @Date: 2017-10-21 15:47
# -*- coding: utf-8 -*-

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import time
from lib.emails.attachment import Attachment
'''
This class is doing like put the email object to envelope.
Fill the from email address, to email address and so on
Then send it to the recipients.
'''

class SMTPEmail(object):
    def __init__(self, from_email,
                       passwd_email,
                       smtp_name,
                       *email_objs):
        self.from_email = from_email
        self.passwd_email = passwd_email
        self.smtp_name = smtp_name
        self.email_objs = list(email_objs)

    def packaging_email(self, email_obj):
        mail_msg = MIMEMultipart()
        mail_msg['Subject'] = email_obj.get_subject()
        mail_msg['From'] = self.from_email
        mail_msg['To'] = ','.join(email_obj.get_to_emails())
        mail_msg.attach(MIMEText(email_obj.get_content()))
        mail_msg['date'] = time.strftime('%a, %d %b %Y %H:%M:%S %z')

        attach_objs = Attachment(email_obj.get_attachment_path())
        for att in attach_objs.attachs:
            mail_msg.attach(att)
        return mail_msg

    def send(self, *email_objs):
        for email in email_objs:
            if email not in self.email_objs:
                self.email_objs.append(email)
        try:
            s = smtplib.SMTP()
            s.connect(self.smtp_name)
            s.login(self.from_email, self.passwd_email)
        except Exception as e:
            print("Failed: fail to connect SMTP: %s" % e)

        for email_obj in self.email_objs:
            try:
                mail_msg = self.packaging_email(email_obj)
                s.sendmail(self.from_email, email_obj.get_to_and_bccs(), mail_msg.as_string())
            except Exception as e:
                print("Failed: fail to send email:Error Info %s" % e)

        self.email_objs = []
        try:
            s.quit()
        except smtplib.SMTPServerDisconnected:
            pass


if __name__ == "__main__":
    # python -m lib.emails.smtp_email
    from lib.emails import normal_email
    normal_one = normal_email.NormalEmail()
    smtp_email = SMTPEmail()

    from lib.emails.bcc_email import BCCEmail
    bcc_email = BCCEmail(normal_one, bcc_emails=["huayp@outlook.com"])
    print("Subject: ", bcc_email.get_subject())
    print("To Emails: ", bcc_email.get_to_emails())
    print("Bcc Emails: ", bcc_email.get_bcc_emails())
    print("Content: ", bcc_email.get_content())
    print("To and Bcc Emails", bcc_email.get_to_and_bccs())
    # smtp_email.send(bcc_email)

    from lib.emails.forward_email import ForwardEmail
    print("------Forwarding------")
    forward_eml = ForwardEmail(normal_one)
    print("Subject: ", forward_eml.get_subject())
    print("To Emails: ", forward_eml.get_to_emails())
    print("Bcc Emails: ", forward_eml.get_bcc_emails())
    print("Content: ", forward_eml.get_content())
    print("To and Bcc Emails: ", forward_eml.get_to_and_bccs())
    # smtp_email.send(forward_eml)

    print("--------Bcc then forward -------")
    forward_eml = ForwardEmail(bcc_email)
    print("Subject: ", forward_eml.get_subject())
    print("To Emails: ", forward_eml.get_to_emails())
    print("Bcc Emails: ", forward_eml.get_bcc_emails())
    print("Content: ", forward_eml.get_content())
    print("To and Bcc Emails: ", forward_eml.get_to_and_bccs())
    # smtp_email.send(forward_eml)

    print("-------Forward then Bcc--------")
    bcc_email = BCCEmail(ForwardEmail(normal_one), bcc_emails=["huayp@outlook.com"])
    print("Subject: ", bcc_email.get_subject())
    print("To Emails: ", bcc_email.get_to_emails())
    print("Bcc Emails: ", bcc_email.get_bcc_emails())
    print("Content: ", bcc_email.get_content())
    print("To and Bcc Emails", bcc_email.get_to_and_bccs())
    # smtp_email.send(bcc_email)