#!/usr/bin/env python
# @Filename: decorate_email.py
# @Author: huayp
# @Date: 2017-10-21 11:19
# -*- coding: utf-8 -*-

from lib.emails.emails import Email

'''
This class is for using Decorator Pattern.
Then, when want to forward one email and bcc to someone at the same
we could use the following way:
forward_bcc_email = ForwardEmail(BCCEmail(NormalEmail()))
              or  = BCCEmail(ForwardEmail(NormalEmail()))
NormailEmail() to create one normal email,
Then, it could be bcced then forwarded. Or be forwarded then bcced.
'''
class DecorateEmail(Email):
    def __init__(self, email_encap):
        self.email_encaped = email_encap

    def get_subject(self):
        return self.email_encaped.get_subject()

    # def get_from_email(self):
    #     return self.from_email
    def get_to_emails(self):
        return self.email_encaped.get_to_emails()

    # Usually, the normal email could be sent
    # by bcc
    def get_bcc_emails(self):
        return self.email_encaped.get_bcc_emails()

    def get_content(self):
        return self.email_encaped.get_content()

    def get_attachment_path(self):
        return self.email_encaped.get_attachment_path()

    def get_to_and_bccs(self):
        return self.email_encaped.get_to_and_bccs()


if __name__ == "__main__":
    from lib.emails.normal_email import NormalEmail
    normal_eml = DecorateEmail(NormalEmail())

    print("Subject: ", normal_eml.get_subject())    
    print("To Emails: ", normal_eml.get_to_emails())
    print("Bcc Emails: ", normal_eml.get_bcc_emails())
    print("Content: ", normal_eml.get_content())
    print("To and Bcc Emails", normal_eml.get_to_and_bccs())

    normal_eml = DecorateEmail(normal_eml)
    print("Subject: ", normal_eml.get_subject())    
    print("To Emails: ", normal_eml.get_to_emails())
    print("Bcc Emails: ", normal_eml.get_bcc_emails())
    print("Content: ", normal_eml.get_content())
    print("To and Bcc Emails", normal_eml.get_to_and_bccs())


