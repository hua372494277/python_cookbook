#!/usr/bin/env python
# @Filename: main
# @Author: huayp
# @Date: 2017-11-23 15:51
# -*- coding: utf-8 -*-

from lib.celery.client_worker import scenario_execute, update_itm_automators
import lib.constants.server_info as server_info

import logging
import os
import time

from optparse import OptionParser

class Controller(object):
    def __init__(self, test_path, host_ip, log_dir):
        self.test_path = test_path
        self.host_ip = host_ip
        self.queue_name = "queue_" + host_ip.split('.')[-1]
        self.log_folder = log_dir
        self.result = None


    def pre_test(self):
        # update ITM_Automators Codes
        update_itm_automators.apply_async((), queue = self.queue_name)
        print("Update ITM_Automators on %s" % self.host_ip)


    def main(self):
        print("Execute the test cases in %s" % self.test_path)
        print("Distribute the job on queue: ", self.queue_name )
        async_result = scenario_execute.apply_async(["python -m robot -d C:\\ITM_Automators\\ --variable TRIGGER_HOST_IP:" + self.host_ip + " " + self.test_path],
                                                    queue=self.queue_name)

        wait_celery_result(async_result)
        print(async_result.result)

    def post_test(self):
        print("Copy the log back to Jenkins server......")
        async_result = scenario_execute.apply_async(("C:\\ITM_Automators\\bin\\pscp.exe -pw \""+
                                                     server_info.server_passwd +"\" C:\\ITM_Automators\\log.html " +
                                                     server_info.server_username + "@" +
                                                     server_info.server_ip + ":" + self.log_folder,),
                                                    queue = self.queue_name)
        wait_celery_result(async_result, delay=2)
        print("Copy log.html from host")
        async_result = scenario_execute.apply_async(("C:\\ITM_Automators\\bin\\pscp.exe -pw \""+
                                                     server_info.server_passwd +"\" C:\\ITM_Automators\\output.xml " +
                                                     server_info.server_username + "@" +
                                                     server_info.server_ip + ":" + self.log_folder,),
                                                    queue = self.queue_name)
        wait_celery_result(async_result, delay=2)
        print("Copy output.xml from host")

        async_result = scenario_execute.apply_async(("C:\\ITM_Automators\\bin\\pscp.exe -pw \""+
                                                     server_info.server_passwd +"\" C:\\ITM_Automators\\report.html " +
                                                     server_info.server_username + "@" +
                                                     server_info.server_ip + ":" + self.log_folder,),
                                                    queue = self.queue_name)
        wait_celery_result(async_result, delay=2)
        print("copy report.html from host")



def wait_celery_result(res_object, delay = 60):
    while res_object.status != 'SUCCESS':
        if res_object.status == 'FAILURE':
            logging.error("celery execution failed")
            break
        else:
            time.sleep(delay)


if __name__ == "__main__":
    usage = "usage: %prog [options] arg"
    parser = OptionParser(usage)
    parser.add_option("-f", "--file", dest="filename",
                      help="read test cases from FILENAME")

    parser.add_option("--host", dest="host",
                      help="The tests runs on the host")

    parser.add_option("--log", dest="log_path",
                      help="The logs will be saved to log path")

    (options, args) = parser.parse_args()
    print(options)

    if options.filename == None or options.host == None:
        parser.error("incorrect number of arguments")

    control = Controller(test_path=options.filename, host_ip = options.host, log_dir = options.log_path)

    print("=" * 20, "Pre Test", "=" * 20)
    control.pre_test()
    print("=" * 20, "Main", "=" * 20)
    control.main()
    print("="*20, "Post Test", "="*20)
    control.post_test()
    # if options.verbose:
    #     print("reading %s..." % options.filename)
