#!/usr/bin/env python
# @Filename: check_score
# @Author: huayp
# @Date: 2017-12-11 11:00
# -*- coding: utf-8 -*-



