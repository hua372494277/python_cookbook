#!/usr/bin/env python
# @Filename: common_func
# @Author: huayp
# @Date: 2017-12-12 14:41
# -*- coding: utf-8 -*-

import random
from tests.ERS.constants.attachment_paths import attachment_paths
from tests.ERS.constants.email_constants import email_constants
from tests.ERS.common_func.common_func import get_bad_subject
from lib.trigger.email_trigger_itm import EmailTriggerITM
import time

def hit_random_email_itms(hit_params):
    choose = random.choice(hit_params)
    attaching_path = []
    bcc = False
    fw = False
    subject = email_constants['subject']
    to_emails = email_constants['to_emails']

    if 'hit_bccs' == choose:
        bcc = True
    if 'hit_fws' == choose:
        fw = True
    cur_path = attachment_paths[choose[4:] + '_path']
    if cur_path:
        attaching_path.append(cur_path)
    if choose == 'hit_self_outside':
        to_emails = email_constants['self_outside_emails']
    elif choose == 'hit_bad_info':
        subject = get_bad_subject()


    eml_trig = EmailTriggerITM(from_email=email_constants['from_email'],
                               passwd_email=email_constants['email_passwd'],
                               smtp_name=email_constants['smtp_name'],
                               subject=subject,
                               to_emails=to_emails,
                               bcc_emails=email_constants['bcc_emails'],
                               content=email_constants['content'],
                               attachment_paths=attaching_path
                               )
    resp = eml_trig.trigger(bcc=bcc, fw=fw)
    print(resp)

'''
unit of duration and iterval: seconds
'''
def set_duration(duration, interval, hit_itm = True):
    hit_params = [ 'hit_cust_info', 'hit_encrypts', 'hit_resume', 'hit_cert_key', 'hit_bad_info', #'hit_bccs', 'hit_fws',
                  'hit_normal_file', 'hit_passwd', 'hit_self_outside', 'hit_src_code', 'hit_unknown_type', ]
    hit_normal_file = ['hit_normal_file']
    print("Start to hit itms randomly")
    end = time.time() + int(duration)

    while time.time() < end:
        if hit_itm:
            hit_random_email_itms(hit_params)
        else:
            hit_random_email_itms(hit_normal_file)
        time.sleep(interval)

    print("End")

if __name__ == '__main__':
    set_duration(2*60*60, 5)
