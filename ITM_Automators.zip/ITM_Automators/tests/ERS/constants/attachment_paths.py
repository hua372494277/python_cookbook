#!/usr/bin/env python
# @Filename: attachment_paths.py
# @Author: huayp
# @Date: 2017-12-01 11:02
# -*- coding: utf-8 -*-
import os
this_file_abspath = os.path.realpath(__file__)
print(this_file_abspath)
current_dir = os.path.dirname(this_file_abspath)
directory_path = os.path.normpath(os.path.join(current_dir, "..", "..", "..", "lib", "emails", "attachments"))
# directory_path = 'C:\\ITM_Automators\\lib\\emails\\attachments\\'

attachment_paths={
    'encrypts_path':     os.path.join(directory_path, 'ITM-01-encrypted_file.docx'),
    'unknown_type_path': os.path.join(directory_path, 'ITM-02-unknown_type.zip'),
    'passwd_path':       os.path.join(directory_path, 'ITM-08-SAM_Passwd'),
    'resume_path':       os.path.join(directory_path, 'ITM-09-resume.pdf'),
    'bad_info_path':     None,
    'cust_info_path':    os.path.join(directory_path, 'ITM-13-cust_info.xlsx'),
    'src_code_path':     os.path.join(directory_path, 'ITM-15.c'),
    'compress_slice_path': os.path.join(directory_path, 'ITM-inside-slice.rar'),
    'encrypt_deep_path': os.path.join(directory_path, 'ITM-inside-encrypt_deep.rar'),
    'type_ inconst_path': os.path.join(directory_path, 'ITM-inside-type_changed.txt'),
    'normal_file_path':  os.path.join(directory_path, 'normal_file.jpg'),
    'inside_itm_path':   os.path.join(directory_path, 'ITM-inside-type_changed.txt'),
    'cert_key_path':     os.path.join(directory_path, 'ITM-03-cert_key.zip'),
    'self_outside_path': None,
    'bccs_path':         None,
    'fws_path':          None,
    'blank_path':        None,
}


if __name__ == "__main__":
    import os

    for key, value in attachment_paths.items():
        if value:
            print(value)
            if os.path.exists(value):
                print(key)
            else:
                print("Key no found")