#!/usr/bin/env python
# @Filename: es_info
# @Author: huayp
# @Date: 2017-12-01 16:51
# -*- coding: utf-8 -*-
es_info = {
    'es_server_ip': '172.22.73.230',
    'es_server_port': '9200',
    'es_server_username': "",
    'es_server_passwd': "",
    'device_id': "497befd3-38a9-a4dc-2123-7cf97f5581b2"
}
