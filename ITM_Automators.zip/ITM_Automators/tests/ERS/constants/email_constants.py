#!/usr/bin/env python
# @Filename: email_constants.py
# @Author: huayp
# @Date: 2017-12-01 16:01
# -*- coding: utf-8 -*-

email_constants = {
    'from_email': 'testitm@sina.com',
    'email_passwd': 'Hello123!',
    'smtp_name': 'smtp.sina.com',
    'subject': 'noblank',
    'content': 'helloworld',
    'to_emails': ['yongpanhua@163.com'],
    'self_outside_emails': ['testitm@163.com'],
    'bcc_emails': ['huayp@outlook.com']
}



