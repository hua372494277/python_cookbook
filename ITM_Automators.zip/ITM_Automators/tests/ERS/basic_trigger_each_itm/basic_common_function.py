#!/usr/bin/env python
# @Filename: itm_strategies_test.py
# @Author: huayp
# @Date: 2017-10-25 10:42
# -*- coding: utf-8 -*-

import datetime
import random
import time


from lib.es.incident_search.incident_search import IncidentSearch
from tests.ERS.constants.es_info import es_info


def verify_itms_triggered(trigger_host_ip, *itm_uuids):
    print(trigger_host_ip)
    print(list(itm_uuids))
    incdt_search = IncidentSearch(es_server_ip = es_info['es_server_ip'],
                         es_server_port = es_info['es_server_port'],
                         es_server_username = es_info['es_server_username'],
                         es_server_passwd = es_info['es_server_passwd'],
                         dlp_log_src_ip = [es_info['device_id']],
                         trigger_host_ip = [trigger_host_ip])

    cur_time = datetime.datetime.now()
    search_win_start = cur_time - datetime.timedelta(minutes=3)
    search_win_end = cur_time
    print(search_win_start.strftime("%Y-%m-%d %H:%M:%S"), " - ", search_win_end.strftime("%Y-%m-%d %H:%M:%S"))
    return incdt_search.verify_itm_triggered(start_time=search_win_start.strftime("%Y-%m-%d %H:%M:%S"),
                                             end_time=search_win_end.strftime("%Y-%m-%d %H:%M:%S"),
                                             trigger_itms=list(itm_uuids))


if __name__ == "__main__":
    verify_itms_triggered("172.22.1.52", "d59fbb85-26b6-4d86-8a76-86587db356ff",  "8e2d1942-e5bf-497f-9f5a-20de297c760a")
