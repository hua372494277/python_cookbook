#!/usr/bin/env python
# @Filename: bcc_fw_common_function.py
# @Author: huayp
# @Date: 2017-11-13 17:51
# -*- coding: utf-8 -*-
# add this line for testing if the encoding line will 
# affect git's operations.


import datetime
import random
import time

from lib.es.incident_search.incident_search import IncidentSearch
from lib.trigger.email_trigger_itm import EmailTriggerITM

def trigger_itms(from_email, passwd, smtp_name, subject, to_emails, bcc_emails, content, bcc, fw, *attachment_paths):
    print(from_email)
    print(smtp_name)
    print(subject)
    print(to_emails)
    print(bcc_emails)
    print(content)
    print(bcc)
    print(fw)
    print(attachment_paths)

    eml_trig = EmailTriggerITM(from_email=from_email,
                               passwd_email=passwd,
                               smtp_name=smtp_name,
                               subject=subject,
                               to_emails=to_emails,
                               bcc_emails=bcc_emails,
                               content = content,
                               attachment_paths=attachment_paths
                              )

    resp = eml_trig.trigger(bcc=bcc, fw=fw)
    print(resp)
    cur_time = datetime.datetime.now()
    search_win_start = cur_time - datetime.timedelta(minutes=3)
    search_win_end = cur_time + datetime.timedelta(minutes=2)

    return (search_win_start.strftime("%Y-%m-%d %H:%M:%S"), search_win_end.strftime("%Y-%m-%d %H:%M:%S"))


def verify_itms_triggered(es_server_ip, es_server_port, es_server_username, es_server_passwd,
                          dlp_log_src_ip, trigger_host_ip, start_time, end_time, *itms):
    print(es_server_ip, es_server_port, es_server_username, es_server_passwd)
    print(dlp_log_src_ip)
    print(trigger_host_ip)
    print(list(itms))
    incdt_search = IncidentSearch(es_server_ip = es_server_ip,
                         es_server_port = es_server_port,
                         es_server_username = es_server_username,
                         es_server_passwd = es_server_passwd,
                         dlp_log_src_ip = [dlp_log_src_ip],
                         trigger_host_ip = [trigger_host_ip])
    return incdt_search.verify_itm_triggered(start_time=start_time, end_time=end_time, trigger_itms=list(itms))

def restart_bcc_fw_stole_data_scenario(es_server_ip, es_server_port, es_server_username, es_server_passwd, itm_config, device_id, uuid):
    ers_search = ERSSearch(es_server_ip=es_server_ip,
                           es_server_port=es_server_port,
                           es_server_username=es_server_username,
                           es_server_passwd=es_server_passwd,
                           es_config=itm_config,
                           device_id=device_id
                           )
    ers_search.enable_policy_by_uuid(uuid)


def get_time_interval(es_server_ip, es_server_port, es_server_username, es_server_passwd, itm_config, device_id):
    ers_search = ERSSearch(es_server_ip=es_server_ip,
                           es_server_port=es_server_port,
                           es_server_username=es_server_username,
                           es_server_passwd=es_server_passwd,
                           es_config=itm_config,
                           device_id=device_id
                           )
    return ers_search.get_time_interval()

def get_score(es_server_ip, es_server_port, es_server_username, es_server_passwd, config, device_id, uuid,
              trigger_host_ip, start_time, end_time):
    print("Config: " + config )
    print("Device ID: ", device_id)
    print("Policy UUID: ", uuid)
    print("Trigger Host IP: ", trigger_host_ip)
    print("Search Time Range: ", start_time, " - ", end_time)
    ers_search = ERSSearch(es_server_ip=es_server_ip,
                           es_server_port=es_server_port,
                           es_server_username=es_server_username,
                           es_server_passwd=es_server_passwd,
                           es_config=config,
                           device_id=device_id
                           )
    scores = ers_search.get_ers_scores(start_time=start_time, end_time=end_time, trigger_id = trigger_host_ip, trigger_uuid = uuid)
    return scores.values()

def hit_nodes_bcc_forward_scenario(from_email, passwd, smtp_name, subject, to_emails, bcc_emails, content,
                                   hit_bccs, hit_fws, hit_cust_infos, hit_encrypts,
                                   cust_info_path, encrypt_file_path):

    print(hit_bccs, hit_fws, hit_cust_infos, hit_encrypts)

    send_email_num = 0
    while hit_bccs > 0 or  hit_fws > 0 or  hit_cust_infos > 0 or  hit_encrypts > 0:
        attachment_path = []
        bcc = False
        if hit_bccs > 0:
            bcc = True
            hit_bccs = hit_bccs - 1
            print("It has been bcced to ", bcc_emails)

        fw = False
        if hit_fws > 0:
            fw = True
            hit_fws = hit_fws - 1
            print("It has been fwed to ", to_emails)

        if hit_cust_infos > 0:
            attachment_path.append(cust_info_path)
            hit_cust_infos = hit_cust_infos - 1
            print("Attached Customer or Employee Info")

        if hit_encrypts > 0:
            attachment_path.append(encrypt_file_path)
            hit_encrypts = hit_encrypts - 1
            print("Attached Encrypted files")

        trigger_itms(from_email, passwd, smtp_name, subject, to_emails, bcc_emails, content, bcc, fw,
                         *attachment_path)

        send_email_num += 1
        time.sleep(60)

    return send_email_num


def consume_rest_time(interval, hit_start_tm, hit_end_tm):
    hit_cost_tm  =  datetime.datetime.strptime(hit_end_tm, "%Y-%m-%d %H:%M:%S.%f") - datetime.datetime.strptime(hit_start_tm, "%Y-%m-%d %H:%M:%S.%f")
    total_seconds = hit_cost_tm.total_seconds()
    print("Sending all emails costs %d s" % total_seconds)
    print("Still need to wait %d s" %  (interval - total_seconds))
    time.sleep( interval - total_seconds)
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# change the interval to restart the predict threads
# so it will calculate the scores at once
def predict(es_server_ip, es_server_port, es_server_username, es_server_passwd, itm_config, device_id):
    ers_search = ERSSearch(es_server_ip=es_server_ip,
                           es_server_port=es_server_port,
                           es_server_username=es_server_username,
                           es_server_passwd=es_server_passwd,
                           es_config=itm_config,
                           device_id=device_id
                           )
    ers_search.change_time_interval()

if __name__ == "__main__":
#    verify_itms_triggered("172.22.0.60", 9200, "admin", "Firewall", "172.22.111.100", "172.22.1.52",
#                          "2017-11-11 15:29:00", "2017-11-11 15:33:00",  "员工",  "转发")
    print("hello world")
    print("test if the encoding of line ending affect the running from different os")
