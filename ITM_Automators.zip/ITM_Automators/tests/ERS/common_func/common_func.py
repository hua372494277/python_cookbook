#!/usr/bin/env python
# @Filename: common_func.py
# @Author: huayp
# @Date: 2017-11-30 16:13
# -*- coding: utf-8 -*-

import time
import datetime
from lib.trigger.email_trigger_itm import EmailTriggerITM
from lib.es.ers_search.ers_score_search import ERSScoreSearch
from lib.trigger.github_trigger_itm import GitHubTriggerITM
from lib.trigger.access_http_trigger_itm import AccessHTTPTriggerITM
from tests.ERS.constants.attachment_paths import attachment_paths
from tests.ERS.constants.email_constants import email_constants
from tests.ERS.constants.es_info import es_info
import random

'''
For triggering bad info itm, 
the func generates one special subject.
'''
def get_bad_content():
    bad_content = [ # FaLunGong
                    '''\"法轮大法\"     
                    \"自焚\"         
                    \"打坐\"         
                    \"宇宙大法\"     
                    \"升天\"         
                    \"走向圆满\"     
                    \"天国世界\"     
                    \"法王\"         
                    \"法轮佛法\"     
                    \"转法轮\"       
                    \"法轮佛法大圆满
                    \"李洪志\"       
                    \"放下生死\"     
                    \"大法\"         
                    \"新纪元\"       
                    \"明慧网\"       
                    \"新唐人\"       
                    \"正见网\"       
                    \"真相网\"  ''',
                   # politics
                   '''\"政治主张\",            
                        \"刘晓波\",              
                        \"退党\",                
                        \"九评共产党\",          
                        \"达赖\",                
                        \"热比娅\",              
                        \"东突分子\",            
                        \"世界维吾尔族代表大会\",
                        \"分裂活动\",            
                        \"支持独立\",            
                        \"独立运动\",            
                        \"自治请愿\",            
                        \"独立抗争\",            
                        \"东突\",                
                        \"台独\",                
                        \"藏独\",                
                        \"新疆独立\",            
                        \"言论自由\",            
                        \"政治言论\",            
                        \"基地组织\",            
                        \"恐怖组织\",            
                        \"圣战士\",              
                        \"疆独\",   '''
                   ]
    random_index = random.randint(0, len(bad_content) - 1)
    return bad_content[random_index]

'''
Input:
    the number of action to simulate the email operation
    all values passed by dict as the following:
    {
        'hit_bccs': 0, 
        'hit_fws': 0,
        'hit_cust_info': 0,
        'hit_encrypts': 0,
        'hit_resume': 0,
        'hit_normal_file': 0,
        'hit_inside_itm': 0,
        'hit_passwd': 0,
        'hit_self_outside':0,
        'hit_src_code':0,
        'hit_unknown_type':0,
        'hit_cert_key':0,
        'hit_bad_info':0,
    }
    the corresponding key to the attachment path is: strip out 'hit_' and add '_path' at the end  
'''
def hit_email_nodes_in_scenario(param, email_delay=30):
    print(param)
    hit_params = {
        'hit_bccs': 0,
        'hit_fws': 0,
        'hit_cust_info': 0,
        'hit_encrypts': 0,
        'hit_resume': 0,
        'hit_normal_file': 0,
        'hit_inside_itm': 0,
        'hit_passwd': 0,
        'hit_self_outside': 0,
        'hit_src_code': 0,
        'hit_unknown_type': 0,
        'hit_cert_key': 0,
        'hit_bad_info': 0,
        'hit_blank':0,
    }

    for key in hit_params.keys():
        if key in param:
            hit_params[key] = int(param[key])

    flag_send_email = 'True'
    while flag_send_email:
        attaching_path = []
        bcc = False
        fw = False
        content = email_constants['content']
        to_emails = email_constants['to_emails']

        flag_send_email = False
        for key, value in hit_params.items():
            if value > 0:
                flag_send_email = True
                hit_params[key] = value - 1
                if 'hit_bccs' == key:
                    bcc = True
                if 'hit_fws' == key:
                    fw = True
                cur_path = attachment_paths[key[4:] + '_path']
                if cur_path:
                    attaching_path.append(cur_path)
                if key == 'hit_self_outside':
                    to_emails = email_constants['self_outside_emails']
                elif key == 'hit_bad_info':
                    content = get_bad_content()

        if flag_send_email:
            eml_trig = EmailTriggerITM(from_email=email_constants['from_email'],
                                       passwd_email=email_constants['email_passwd'],
                                       smtp_name=email_constants['smtp_name'],
                                       subject=email_constants['subject'],
                                       to_emails=to_emails,
                                       bcc_emails=email_constants['bcc_emails'],
                                       content=content,
                                       attachment_paths=attaching_path
                                       )
            resp = eml_trig.trigger(bcc=bcc, fw=fw)
            print(resp)
            time.sleep(email_delay)

'''
simulate accessing websites
Input => list
         each element => dict
as [ {'count': 1, 'type': 'bbs'}, { 'count':2, 'type': 'adults'}, ...]
'''
def hit_networks_nodes_in_scenario(param, web_delay = 1):
    access_http = AccessHTTPTriggerITM()
    for itm in param:
        access_http.multi_access_with_delay(itm['count'], itm['type'], delay=web_delay)


'''
send file out by uploading to github
but the files are not source codes
'''
def upload_file_to_github(times):
    github_trigger = GitHubTriggerITM()
    github_trigger.send_to_github(times)


def get_score(config, uuid, trigger_host_ip):
    print("Config: " + config )
    print("Policy UUID: ", uuid)
    print("Trigger Host IP: ", trigger_host_ip)
    ers_search = ERSScoreSearch(es_server_ip=es_info['es_server_ip'],
                           es_server_port=es_info['es_server_port'],
                           es_server_username=es_info['es_server_username'],
                           es_server_passwd=es_info['es_server_passwd'],
                           es_config=config,
                           device_id=es_info['device_id']
                           )
    cur_time = datetime.datetime.now()

    scores = ers_search.get_ers_scores(start_time=cur_time.strftime("%Y-%m-%d %H:00:00"), end_time=cur_time.strftime("%Y-%m-%d %H:00:00"),
                                   trigger_id = trigger_host_ip, trigger_uuid = uuid)
    return scores.values()

'''
For aligning time with ERS system
Hitting ITM strategies during the period after even o'clock and an half, 
before the next even o'clock
such as 2:50:00 - 4:00:00
But the starting time point must be between 2:50 - 3:10.
There should be  at least 40 min for executing all kinds of actions
'''
def wait_interval_clock(interval):
    cur_t = time.localtime()

    if cur_t.tm_hour % interval == 0:
        if cur_t.tm_min < 50:
            time.sleep((50 - cur_t.tm_min) * 60 - cur_t.tm_sec)
    elif cur_t.tm_hour % interval == interval - 1:
        if cur_t.tm_min > 10:
            time.sleep((60 - cur_t.tm_min + 50) * 60 - cur_t.tm_sec)

    cur_t = time.localtime()
    print("Htting ITM at %02d:%02d" % (cur_t.tm_hour, cur_t.tm_min))

'''
At even number clock, ERS calculates scores.
The calculation and saving cost several minutes.
Here, at half hours, checking score.
'''
def wait_interval_half_clock(interval):
    cur_t = time.localtime()

    while cur_t.tm_hour % interval != 0:
        time.sleep((60 - cur_t.tm_min) * 60 - cur_t.tm_sec)
        cur_t = time.localtime()
        print("Htting ITM at %02d:%02d" % (cur_t.tm_hour, cur_t.tm_min))

    while cur_t.tm_min < 30:
        time.sleep((30 - cur_t.tm_min) * 60 - cur_t.tm_sec)
        cur_t = time.localtime()
    cur_t = time.localtime()
    print("Even hour and an half Clock pass at %02d:%02d" % (cur_t.tm_hour, cur_t.tm_min))


def verify_same_even_clock(start_t, end_t):
    if start_t.tm_hour == end_t.tm_hour:
        time.sleep(60*60)


# Func: template main including each step
def template_main(param_email, param_website, param_github,
                  config, uuid, trigger_host_ip, trigger_host_name, interval=2):
    print(param_email, param_website, param_github, config, uuid, trigger_host_ip, trigger_host_name, interval)
    # 1. correction time
    wait_interval_clock(int(interval))

    start_t = time.localtime()
    # 2. send emails if need
    if param_email:
        print("Start to send emails out")
        hit_email_nodes_in_scenario(param_email)
    if param_website:
        hit_networks_nodes_in_scenario(param_website)
    if param_github:
        # when SWG works by pass mirror, https cannot be captured
        # So comment out this calling, when changing the working mode
        upload_file_to_github(param_github)
        print("Until device is working at the correct mode")
        print("Github actions will be detected in log")
    end_t = time.localtime()
    # 3. verify if all actions are finished in a same even o'clock
    verify_same_even_clock(start_t, end_t)
    # 4. wait to even o'clock and an half
    wait_interval_half_clock(int(interval))
    # 5. check score
    scores = get_score(config, uuid, trigger_host_ip)
    if len(scores) < 1:
        raise RuntimeError('Not Found the scores between %s and %s...' % (str(start_t), str(end_t)))
    return scores


# Func: normal main including each step
def normal_main(param_email, param_website, param_github, config, uuid, trigger_host_ip):
    print(param_email, param_website, param_github, config, uuid, trigger_host_ip)

    if param_email:
        print("Start to send emails out")
        for i in range(param_email):
            one_email = {}
            one_email['hit_blank'] = 1
            hit_email_nodes_in_scenario(one_email, email_delay = random.randint(60, 7200))
    if param_website:
        access_http = AccessHTTPTriggerITM()
        all_type = list(access_http.website.keys())
        all_type.remove('adult')
        all_type.remove('recruit')
        all_type.remove('virus')
        all_type.remove('unsafe')
        for i in range(param_website):
            random_index = random.randint(0, len(all_type) -1 )
            type = all_type[random_index]
            one_access = {}
            one_access['type'] = type
            one_access['count'] = 1
            hit_networks_nodes_in_scenario([one_access], web_delay=random.randint(10, 7200))
    if param_github:
        # when SWG works by pass mirror, https cannot be captured
        # So comment out this calling, when changing the working mode
        upload_file_to_github(param_github)
        print("Until device is working at the correct mode")
        print("Github actions will be detected in log")


if __name__ == '__main__':
    print("common func in main")
    # scores = get_score("ers_results", "74b5d421-09c5-49ba-ba94-fbbe954f64b5",
    #                    "172.22.76.99")
    # print(scores)
    # pass
    hit_email_nodes_in_scenario({
        # 'hit_bccs': 0,
        # 'hit_fws': 2,
        # 'hit_cust_info': 3,
        # 'hit_encrypts': 5,
        # 'hit_resume': 0,
        'hit_normal_file': 3,
        # 'hit_inside_itm': 1,
        # 'hit_passwd': 0,
        # 'hit_self_outside': 5,
        # 'hit_src_code': 0,
        # 'hit_unknown_type': 0,
        # 'hit_cert_key': 0,
        # 'hit_bad_info': 0,
        # 'subject':"noblank",
        # 'to_emails':['here']
    })