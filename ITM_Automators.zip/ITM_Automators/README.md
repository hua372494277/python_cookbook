# ITM Automators #

> ITM Automators是用来测试ITM系统，包括ITM策略的触发，验证，调用ITM模型进行预测，RPC通信等。   
    

* lib文件夹： 包含框架、通用模块代码，子文件夹将按照不同功能细分。   
* tests文件夹： 包含测试脚本、测试案例文件，按照测试对象分类，分别对应不同文件夹。<br>
<br>

# 环境搭建
## --环境网络要求
远程肉机和测试执行环境的网络是互通的<br>
<br>

## --远程肉机环境搭建<br>
* Python 3.x     (用于RPC通信和执行特定操作)<br>
* Elasticsearch  (pip install --trusted-host pypi.python.org elasticsearch 用于访问ES)<br>
* 代码目前通过邮件附件的方式拷贝过来 （肉机172.22.1.127,172.22.1.52已配置好）<br>
* 然后在命令行中执行，如下代码：<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;python  C:\ITM_Automators\lib\xmlrpc\xmlrpc_server.py<br>
* 肉机上的8000端口就进入了监听状态，并且XMLRPCServer的工作目录是C:\ITM_Automators\。<br>
* 此时，来自测试环境的命令就可以被执行。<br>

## --测试执行环境搭建<br>
* 软件和Python包
<br>
Python 3.x <br>
Git  (pull和checkout代码) <br>
Robot Framework    （可选，为以后自动化测试生成格式化的日志）<br>
Tensorflow    （暂时，为了支持运行MRS模型）<br>
.... 此处省略了一些ERS和MRS模型需要的相关包<br>
<br>
* 环境配置<br>
<br>
    1. 下载代码，从http://172.30.3.101/huayongpan/ITM_Automators/tree/huayp 下载下来(暂时从这里下载，以后使用http://172.30.3.101/ml/ITM_Automators)<br>假设我将代码ITM_Automators，下载并放在了C:\下面<br>
    2. 打开命令行<br> cd C:\ITM_Automators <br> 
    3. 运行python，进入python交互模式
    4. 导入XMLRPCClient包
    5. from lib.xmlrpc.xmlrpc_client import XMLRPCClient
    6. 初始化XMLRPCClient一个实例，假如要和肉机172.22.1.52交互
    7. xmlrpc_client = XMLRPCClient(server_ip="172.22.1.52", server_port="8000")xmlrpc_client = XMLRPCClient(server_ip="172.22.1.52", server_port="8000")
    8. 如果输出The communication is good，说明链接成功，并且通信正常
    9. 如果现在想发一封邮件，去触发ITM-01和ITM-02，并且还想添加一个特定的附件，它在肉机172.22.1.52C盘下面normal_file.bat
    10. 那么，执行 <br>resp = xmlrpc_client.run("python -m lib.trigger.email_trigger_itm from_email=huayongpan@skyguard.com.cn passwd_email=Tencent123# smtp_name=smtp.skyguard.com.cn subject=noblank to_emails=[yongpanhua@163.com] content=helloworld bcc_emails=[huayp@outlook.com] trigger_itms=[itm-01,itm-02] attachment_paths=[C:\\normal_file.bat]")
    11. 执行之后，会回显发送时间和发送的命令
    12. 整个执行内容如下：<br>C:\ITM_Automators>python
Python 3.5.4 |Anaconda custom (64-bit)| (default, Aug 14 2017, 13:41:13) [MSC v.1900 64 bit (AMD64)] on win32<br>
Type "help", "copyright", "credits" or "license" for more information.<br>
>>> from lib.xmlrpc.xmlrpc_client import XMLRPCClient<br>
>>> xmlrpc_client = XMLRPCClient(server_ip="172.22.1.52", server_port="8000")<br>
The communication is good<br>
>>> resp = xmlrpc_client.run("python -m lib.trigger.email_trigger_itm from_email=huayongpan@skyguard.com.cn passwd_email=Tencent123# smtp_name=smtp.skyguard.com.cn subject=noblank to_emails=[yongpanhua@163.com] content=helloworld bcc_emails=[huayp@outlook.com] trigger_itms=[itm-01,itm-02] attachment_paths=[C:\\normal_file.bat]")<br>
Sat, 28 Oct 2017 11:23:08 +0800:  python -m lib.trigger.email_trigger_itm from_email=huayongpan@skyguard.com.cn passwd_email=Tencent123# smtp_name=smtp.skyguard.com.cn subject=noblank to_emails=[yongpanhua@163.com] content=helloworld bcc_emails=[huayp@outlook.com] trigger_itms=[itm-01,itm-02] attachment_paths=[C:\normal_file.bat]<br>
<br>

-----至此，测试环境可以使用了！！！，以下详细描述上面调用过程和包。<br>
<br>


# ITM_Automators目录介绍
&nbsp;&nbsp;ITM_Automators<br>
&nbsp;&nbsp;|----lib&nbsp;&nbsp;(包含commen classes和functions)<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|--emails&nbsp;&nbsp;（包含了email class，实现普通邮件，转发和密送，附件等功能）<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|--es&nbsp;&nbsp;（包含ES class，负责链接ES，封装ES查询quary，处理检测结果等）<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|--trigger<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|--xmlrpc<br>
&nbsp;&nbsp;|--tests<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|--ERS_test<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|--MRS_test<br>
&nbsp;&nbsp;|--README.md<br>
<br>

# XMLRPCServer 详细说明
* 这个类一定要最先运行，因为所有的ITM触发操作必须在肉机上面完成，才能被北京的设备检测到。所以要让肉机先进入监听等待状态。<br>
* XMLRPCServer Class在ITM_Automators/lib/xmlrpc/xmlrpc_server.py中定义。<br>
* 在肉机上面直接运行该脚本中，会自动实例化一个XMLRPCServer，并开始监听肉机的8000端口。<br>
* 例如：<br> python  C:\ITM_Automators\lib\xmlrpc\xmlrpc_server.py<br>

# XMLRPCClient 详细说明
* XMLRPCClient Class在ITM_Automators/lib/xmlrpc/xmlrpc_client.py中定义。因此，在使用之前需要先引用它，如下：<br>from lib.xmlrpc.xmlrpc_client import XMLRPCClient<br>
* 在实例化XMLRPCClient需要提供两个参数server_ip="172.22.1.52"和server_port="8000"<br>  ----server_ip： 肉机的IP，并且在此之前，肉机上面已经运行了xmlrpc_server.py <br>  ----server_port=8000：直接赋值8000，因为在xmlrpc_server.py中会默认监听肉机上8000端口 <br>
* 例如: 肉机172.22.1.52上面已经进入了监听状态，现在链接它<br>   xmlrpc_client = XMLRPCClient(server_ip="172.22.1.52", server_port="8000")<br>

## XMLRPCClient.run() 调用肉机执行命令
看上面的例子：<br>
xmlrpc_client.run("python -m lib.trigger.email_trigger_itm from_email=huayongpan@skyguard.com.cn passwd_email=Tencent123# smtp_name=smtp.skyguard.com.cn subject=noblank to_emails=[yongpanhua@163.com] content=helloworld bcc_emails=[huayp@outlook.com] trigger_itms=[itm-01,itm-02] attachment_paths=[C:\\normal_file.bat]")<br>
其中的参数是一个很长的字符串，下面详细分析：<br>
&nbsp;&nbsp;&nbsp;&nbsp;python -m lib.trigger.email_trigger_itm  (在肉机上面，python运行 lib.trigger.email_trigger_itm模块，这个模块需要发邮件的参数)<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;from_email=huayongpan@skyguard.com.cn<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;passwd_email=Tencent123# <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;smtp_name=smtp.skyguard.com.cn<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;subject=noblank <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;to_emails=[yongpanhua@163.com] <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;content=helloworld <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;bcc_emails=[huayp@outlook.com]<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;trigger_itms=[itm-01,itm-02] <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;attachment_paths=[C:\\normal_file.bat]")<br>
将上面的参数相互之间用空格连接起来，作为字符串参数传递给xmlrpc_client.run()。就可以远程调用肉机发送邮件，从而触发ITM策略。


